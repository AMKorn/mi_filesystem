#include "directorios.h"

int main(int argc, char **argv){
    if (argc != 3){
        printf("Sintaxis: ./mi_rm <disco> </ruta>\n");
        return -1;
    }

    if(bmount(argv[1]) == -1){
        return -1;
    }
	
	stat_t stat;
    if(mi_stat(argv[2],&stat) == -1){
        printf("No puedes borrar el directorio raíz.\n");
        if(bumount(argv[1]) == -1){
            return -1;
        }
        return 0;
    }

    if(stat.tipo == 'd'){
        printf("Error: no es un fichero\n");
		return -1;
    }
    else if (stat.tipo == 'f'){
        if(mi_unlink(argv[2]) == -1){
            puts("Error en mi_unlink.\n");
            return -1;
        }
        printf("\nHas eliminado el fichero con éxito.\n");
    } 
    else{
        printf("Error en mi_rm.\n");
    }

    if(bumount(argv[1]) == -1){
        return -1;
    }

    return 0;
}