#include "directorios.h"

int main(int argc, char **argv){
    if (argc != 3){
        printf("Sintaxis: ./mi_rmdir <disco> </ruta>\n");
        return -1;
    }

    if(bmount(argv[1]) == -1){
        return -1;
    }
	
	stat_t stat;
    if(mi_stat(argv[2],&stat) == -1){
        printf("No puedes borrar el directorio raíz.\n");
        if(bumount(argv[1]) == -1){
            return -1;
        }
        return 0;
    }

	if(stat.tipo == 'f'){
		printf("Error: no es un directorio\n");
		return -1;
    }
	
    if(stat.tipo == 'd' && stat.tamEnBytesLog == 0){
        if(mi_unlink(argv[2]) == -1){
            puts("Error en mi_unlink.\n");
            return -1;
        }
        printf("\nHas eliminado el directorio vacío con éxito.\n");
    }else{
        printf("Error en mi_rm.\n");
    }

    if(bumount(argv[1]) == -1){
        return -1;
    }

    return 0;
}