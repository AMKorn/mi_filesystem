#include "ficheros.h"

#define ERROR_ENTRADA_YA_EXISTENTE -2
#define ERROR_ESCRITURA -3
#define ERROR_EXTRAER_CAMINO -4
#define ERROR_LECTURA -5
#define ERROR_LEER_INODO -6
#define ERROR_LIBERAR_INODO -7
#define ERROR_NO_EXISTE_DIRECTORIO_INTERMEDIO -8
#define ERROR_NO_EXISTE_ENTRADA_CONSULTA -9
#define ERROR_NO_SE_PUEDE_CREAR_ENTRADA_EN_UN_FICHERO -10
#define ERROR_PERMISO_ESCRITURA -11
#define ERROR_PERMISO_LECTURA -12
#define ERROR_RESERVAR_INODO -13
#define num 10

int extraer_camino(const char *camino, char *inicial, char *final);
int buscar_entrada(const char *camino_parcial, unsigned int *p_inodo_dir, unsigned int *p_inodo, unsigned int *p_entrada, int reservar, unsigned char permisos);
int mi_creat(const char *camino, unsigned char permisos);
int mi_dir(const char *camino, char *buffer, int tipo);
int mi_chmod(const char *camino, unsigned char permisos);
int mi_stat(const char *camino, stat_t *p_stat);
int mi_read(const char *camino, void *buf, unsigned int offset, unsigned int nbytes);
int mi_write(const char *camino, const void *buf, unsigned int offset, unsigned int nbytes);
int mi_link(const char *camino1, const char *camino2);
int mi_unlink(const char *camino);

struct entrada{
	char nombre[60];  //En el SF ext2 la longitud del nombre es 255
	unsigned int ninodo;
};

struct UltimaEntrada{
    char camino [512];
    unsigned int p_inodo;
};

struct UltimaEntrada UltimaEntradaLectura[num];
struct UltimaEntrada UltimaEntradaEscritura[num];

