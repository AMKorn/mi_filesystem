#include "directorios.h"
#define TamBuff 100*1000

int main(int argc, char **argv){
    int a, b, tipo;
	if(argc == 3){
	    tipo = 0;
	    a = 1;
	    b = 2;
    }else if(argc == 4){
        if(strcmp(argv[1], "-l") != 0){
            printf("Sintaxis ls -l: ./mi_ls -l <disco> </ruta_directorio>\n");
            return -1;
        }
        tipo = 1;
	    a = 2;
	    b = 3;
    }else{
        printf("Sintaxis ls: ./mi_ls <disco> </ruta_directorio>\n");
        printf("Sintaxis ls -l: ./mi_ls -l <disco> </ruta_directorio>\n");
        return -1;
    }
	
	if(bmount(argv[a]) == -1){
		return -1;
	}
    
    char buff[TamBuff];
    if(mi_dir(argv[b], (char *)buff, tipo) == -1){
        return -1;
    }
	
    printf("%s", buff);

	if(bumount(argv[a]) == -1){
		return -1;
	}
	
	return 0;
}