#include "directorios.h"

int main(int argc, char **argv)
{
	if (argc != 3)
	{
		printf("Sintaxis: ./mi_stat <disco> </ruta>\n");
		return -1;
	}

	if (bmount(argv[1]) == -1)
	{
		return -1;
	}

	stat_t stat;
	struct tm *tm;
	if (mi_stat(argv[2], &stat) == 0)
	{
		printf("tipo: %c \n", stat.tipo);
		//int permisos = (int) stat.permisos;
		printf("permisos: %d \n", stat.permisos);
		tm = localtime(&stat.atime);
		printf("atime: %d-%02d-%02d %02d:%02d:%02d\t \n", tm->tm_year + 1900, tm->tm_mon + 1, tm->tm_mday, tm->tm_hour, tm->tm_min, tm->tm_sec);
		tm = localtime(&stat.mtime);
		printf("mtime: %d-%02d-%02d %02d:%02d:%02d\t \n", tm->tm_year + 1900, tm->tm_mon + 1, tm->tm_mday, tm->tm_hour, tm->tm_min, tm->tm_sec);
		tm = localtime(&stat.ctime);
		printf("ctime: %d-%02d-%02d %02d:%02d:%02d\t \n", tm->tm_year + 1900, tm->tm_mon + 1, tm->tm_mday, tm->tm_hour, tm->tm_min, tm->tm_sec);
		printf("nlinks: %d \n", stat.nlinks);
		printf("tamEnBytesLog: %d \n", stat.tamEnBytesLog);
		printf("numBloquesOcupados: %d \n", stat.numBloquesOcupados);
	}
	else
	{
		printf("Error: mi_stat ha fallado.\n");
	}

	if (bumount(argv[1]) == -1)
	{
		return -1;
	}

	return 0;
}