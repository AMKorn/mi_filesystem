#include "directorios.h"

int main (int argc, char **argv) {
	if (argc != 3) {
		printf("Sintaxis: ./mi_cat <disco> </ruta_fichero>\n");
		return -1;
	}

	char *camino = argv[2];
    if(camino[strlen(camino)-1] == '/'){
        printf("ERROR: ( %s ) no es un fichero.\n",camino);
        return -1;
    }

	if(bmount(argv[1]) == -1){
		return -1;
	}

 	int leidos = 0;
	unsigned char buf[BLOCKSIZE];
	memset(buf,0,BLOCKSIZE);
	int x;
	if((x = mi_read(camino,buf,0,BLOCKSIZE)) == -1){
		return -1;
	}
	
	for(unsigned int bucle = BLOCKSIZE; x > 0; bucle += BLOCKSIZE){ // Mientras no de error seguimos leyendo
		if(write(1, buf, x) == -1){ //Mostrar los resultados por pantalla
			return -1;
		}
		
		leidos += x;
		memset(buf,0,BLOCKSIZE);
		if((x = mi_read(camino, buf, bucle, BLOCKSIZE)) == -1){
			return -1;
		}
		
	}

	char string[128];
	sprintf(string, "\nBytes Leídos: %d\n", leidos); //Hay que mostrar el valor del num de bytes leidos y del tamanyo en bytes logico del inodo
	if(write(2, string, strlen(string)) == -1){
		return -1;
	}

	if(bumount() == -1){
		return -1;
	}
	
	return 0;
}