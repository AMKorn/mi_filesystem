#include "ficheros.h"
#include <string.h>
#include <stdio.h>
#include <errno.h>

int main (int argc, char **argv){
	if(argc != 4){
		printf("Sintaxis: escribir <nombre_dispositivo> <\"$(cat fichero)\"> <diferentes_inodos>\n");
		return -1;
 	}

	if(bmount(argv[1]) == -1){
		printf("\nFallo al montar el disco\n");
		return -1;
	}

	unsigned int offsets[5] = {0,5120,256000,30720000,71680000};
	unsigned int ninodo;
	unsigned int nbytes = strlen(argv[2]);
	inodo_t inodo;
	struct tm *ts;
    char atime[80];
    char mtime[80];
    char ctime[80];
	printf("Longitud texto: %d\n", nbytes);
	char buffer[nbytes];
	memset(buffer, 0, nbytes);
	memcpy(buffer, argv[2], nbytes);

	for (int i = 0; i < 5; i++){
		if(atoi(argv[3]) != 0 || ((atoi(argv[3]) == 0) && i == 0)){
			ninodo = reservar_inodo('f', 6);
			if(ninodo == -1){
				break;
			}
		}

		printf("\nNumero Inodo reservado: %d\n", ninodo);
		printf("Offset: %d\n", offsets[i]);
		if(mi_write_f(ninodo, buffer, offsets[i], nbytes) == -1){
			break;
		}
				
		printf("Bytes escritos: %d\n", nbytes);		
		printf("\nDatos inodo %d\n",ninodo);
		if(leer_inodo(ninodo, &inodo) == -1){
			break;
		}

		ts = localtime(&inodo.atime);
		strftime(atime, sizeof(atime), "%a %Y-%m-%d %H:%M:%S", ts);
		ts = localtime(&inodo.mtime);
		strftime(mtime, sizeof(mtime), "%a %Y-%m-%d %H:%M:%S", ts);
		ts = localtime(&inodo.ctime);
		strftime(ctime, sizeof(ctime), "%a %Y-%m-%d %H:%M:%S", ts);
		printf("tipo: %c\n", inodo.tipo);
    	printf("permisos: %c\n", inodo.permisos);
    	printf("atime: %s\n", atime);
    	printf("ctime: %s\n", ctime);
    	printf("mtime: %s\n", mtime);
    	printf("nlinks: %d\n", inodo.nlinks);
    	printf("tamEnBytesLog: %d\n", inodo.tamEnBytesLog);
    	printf("numBloquesOcupados: %d\n", inodo.numBloquesOcupados);
	}
	
	if(bumount(argv[1]) == -1){
		return -1;
	}
}