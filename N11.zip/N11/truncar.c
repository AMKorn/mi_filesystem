#include "ficheros.h"

int main(int argc, char **argv){
	if (argc != 4) {
		perror("Sintaxis: truncar <nombre_dispositivo> <ninodo> <nbytes>");
		return -1;
	}
	
	if(bmount(argv[1]) == -1){
		return -1;
	}

	int ninodo = atoi(argv[2]);
	int nbytes = atoi(argv[3]);
	inodo_t inodo;
	if(leer_inodo(ninodo, &inodo) == -1){
		bumount();
		return -1;
	}
		
	if(mi_truncar_f(ninodo, nbytes) == -1){
		bumount();
		return -1;
	}

	struct tm *ts;
    char atime[80];
    char mtime[80];
    char ctime[80];
	printf("\nDatos inodo %d\n", ninodo); 
	if(leer_inodo(ninodo, &inodo) == -1){
		bumount();
		return -1;
	}

	ts = localtime(&inodo.atime);
	strftime(atime, sizeof(atime), "%a %Y-%m-%d %H:%M:%S", ts);
	ts = localtime(&inodo.mtime);
	strftime(mtime, sizeof(mtime), "%a %Y-%m-%d %H:%M:%S", ts);
	ts = localtime(&inodo.ctime);
	strftime(ctime, sizeof(ctime), "%a %Y-%m-%d %H:%M:%S", ts);
	printf("tipo: %c\n", inodo.tipo);
	printf("permisos: %c\n", inodo.permisos);
	printf("atime: %s\n", atime);
    printf("ctime: %s\n", ctime);
	printf("mtime: %s\n", mtime);
	printf("nlinks: %d\n", inodo.nlinks);
	printf("tamEnBytesLog: %d\n", inodo.tamEnBytesLog);
	printf("numBloquesOcupados: %d\n", inodo.numBloquesOcupados);
  	
	if(bumount() == -1){
		return -1;
	}
	
	return 0;
}