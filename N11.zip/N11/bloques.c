#include "bloques.h"

static int descriptor = 0;

int bmount(const char *camino){
    descriptor = open(camino, O_RDWR|O_CREAT, 0666);
    if(descriptor == -1){
        perror("Error: ");
    }
    return descriptor;
}

int bumount(){
    if(close(descriptor) == -1){
        perror("Error: ");
        return -1;
    }
    return 0;
}

int bwrite(unsigned int nbloque, const void *buf){
    if(lseek(descriptor, nbloque * BLOCKSIZE, SEEK_SET) == -1){
        perror("Error: ");
        return -1;
    }

    return write(descriptor, buf, BLOCKSIZE);
}

int bread(unsigned int nbloque, void *buf){
    if(lseek(descriptor, nbloque * BLOCKSIZE, SEEK_SET) == -1){
        perror("Error: ");
        return -1;
    }

    return read(descriptor, buf, BLOCKSIZE);
}