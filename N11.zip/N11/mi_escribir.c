#include "directorios.h"

int main (int argc, char **argv) {
	if (argc != 5) {
		printf("Sintaxis correcta: mi_escribir <disco> <ruta_fichero> <texto>  <offset>\n");
		return -1;
	}
    
	char *camino = argv[2];
    if(camino[strlen(camino)-1] == '/'){
        printf("ERROR: ( %s ) no es un fichero.\n",camino);
        return -1;
    }
	bmount(argv[1]);
	int offset = atoi(argv[4]);

	int size = strlen(argv[3]);
    char buffer[size];
    strcpy (buffer, argv[3]);
    int bytes_escritos = mi_write(camino, &buffer, offset, size);
	if(bytes_escritos < 0) {
		printf("Error al escribir.\n");
	}
	printf("Bytes escritos: %d\n",bytes_escritos);
	bumount();
}