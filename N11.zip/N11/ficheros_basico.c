#include "ficheros_basico.h"

int tamMB(unsigned int nbloques){
    int res = ((nbloques/8)/BLOCKSIZE);

    if((nbloques/8)%BLOCKSIZE == 0){
        return res;
    }else{
        return res+1;
    }
}

int tamAI(unsigned int ninodos){
    int res = (ninodos*INODOSIZE)/BLOCKSIZE;

    if((ninodos*INODOSIZE)%BLOCKSIZE == 0){
        return res;
    }else{
        return res+1;
    }
}

int initSB(unsigned int nbloques, unsigned int ninodos){    
    struct superbloque SB;

    SB.posPrimerBloqueMB = posSB + tamSB;
    SB.posUltimoBloqueMB = SB.posPrimerBloqueMB + tamMB(nbloques)-1;
    SB.posPrimerBloqueAI = SB.posUltimoBloqueMB + 1;
    SB.posUltimoBloqueAI = SB.posPrimerBloqueAI + tamAI(ninodos)-1;
    SB.posPrimerBloqueDatos = SB.posUltimoBloqueAI + 1;
    SB.posUltimoBloqueDatos = nbloques - 1;
    SB.posInodoRaiz = 0;
    SB.posPrimerInodoLibre = 0;
    SB.cantInodosLibres = ninodos;
    SB.totInodos = ninodos;
    SB.cantBloquesLibres = nbloques;
    SB.totBloques = nbloques;

    return bwrite(posSB, &SB);
}

int initMB(){
    struct superbloque SB;
    if(bread(posSB, &SB) == -1){
        return -1;
    }

    unsigned char buf[BLOCKSIZE];
    memset(buf,0,BLOCKSIZE);
    for(int i = SB.posPrimerBloqueMB; i <= SB.posUltimoBloqueMB; i++){
        if(bwrite(i,buf) == -1){
            return -1;
        }
    }

    int i = 0;
    while(i <= SB.posUltimoBloqueAI){
        if(escribir_bit(i, 1) == -1){
            return -1;
        }

        i++;
    }

	SB.cantBloquesLibres = SB.cantBloquesLibres - i;		
	if(bwrite(posSB, &SB)<0){
		return -1;
	}
    
    return 0;
}

int initAI(){
    inodo_t inodos[BLOCKSIZE/INODOSIZE];
    struct superbloque SB;

    if(bread(posSB, &SB) == -1){
        return -1;
    }

    int continodos = SB.posPrimerInodoLibre + 1;
    for(int i = SB.posPrimerBloqueAI; i <= SB.posUltimoBloqueAI; i++){
        for(int j = 0; j < (BLOCKSIZE/INODOSIZE); j++){
            inodos[j].tipo = 'l';
            if(continodos < SB.totInodos){
                inodos[j].punterosDirectos[0] = continodos;
                continodos++;
            }else{
                inodos[j].punterosDirectos[0] = UINT_MAX;
                j = (BLOCKSIZE/INODOSIZE);
            }
        }

        if(bwrite(i,inodos) == -1){
            return -1;
        }
    }

    return 0;
}

int escribir_bit(unsigned int nbloque, unsigned int bit){
	struct superbloque SB;
	if(bread(posSB, &SB) == -1){
		return -1;
	}

	unsigned char bufferMB[BLOCKSIZE];
	unsigned int posbyte = nbloque/8;
	unsigned int posbit = nbloque%8;
	unsigned int nbloqueMB = posbyte/BLOCKSIZE;
	unsigned int nbloqueabs = SB.posPrimerBloqueMB + nbloqueMB;
	posbyte = posbyte % BLOCKSIZE;
	unsigned char mascara = 128;
	mascara >>= posbit;
	if(bread(nbloqueabs, bufferMB) == -1){
		return -1;
	}
	
	if(bit){
        bufferMB[posbyte] |= mascara;
    }else{
        bufferMB[posbyte] &= ~mascara;
    }

	if(bwrite(nbloqueabs, bufferMB) == -1){
		return -1;
	}

	return nbloque;
}

unsigned char leer_bit(unsigned int nbloque){
    struct superbloque SB;
    if(bread(posSB, &SB) == -1){
        return -1;
    }

    unsigned int posbyte = nbloque / 8;
    unsigned int posbit = nbloque % 8;
    unsigned int nbloqueMB = posbyte/BLOCKSIZE;
    unsigned int nbloqueabs = nbloqueMB + SB.posPrimerBloqueMB;
    unsigned char bufferMB[BLOCKSIZE];
    
    if(bread(nbloqueabs, bufferMB) == -1){
        return -1;
    }

    posbyte = posbyte % BLOCKSIZE;
    unsigned char mascara = 128;        // 10000000
    mascara >>= posbit;                 // desplazamiento de bits a la derecha
    mascara &= bufferMB[posbyte];       // operador AND para bits
    mascara >>= (7-posbit);             // desplazamiento de bits a la derecha
        
    return mascara;
}

int reservar_bloque(){
    struct superbloque SB;
    if(bread(posSB, &SB) == -1){
        return -1;
    }

    if(!SB.cantBloquesLibres){
        perror("Error: ");
        return -1;
    }

    unsigned char bufferAux[BLOCKSIZE], bufferMB[BLOCKSIZE];
    memset(bufferAux, 255, BLOCKSIZE);

    unsigned int posBloqueMB = SB.posPrimerBloqueMB;
    if(bread(posBloqueMB, bufferMB) == -1){
        return -1;
    }

    while (!memcmp(bufferMB, bufferAux, BLOCKSIZE)){
        posBloqueMB++;
        if(bread(posBloqueMB,bufferMB) == -1){
            return -1;
        }
    }

    unsigned int posbyte = 0;
    while(bufferMB[posbyte] == 255){
        posbyte++;
    }

    unsigned char mascara = 128;
    unsigned int posbit = 0;
    while(bufferMB[posbyte] & mascara) {  
        posbit++;
        bufferMB[posbyte] <<= 1; // desplaz. de bits a la izqda
    }

    int nbloque = ((posBloqueMB - SB.posPrimerBloqueMB) * BLOCKSIZE + posbyte) * 8 + posbit;
    if(escribir_bit(nbloque, 1) == -1){
        return -1;
    }

    SB.cantBloquesLibres = SB.cantBloquesLibres - 1;
    if(bwrite(posSB, &SB) == -1){
        return -1;
    }
    
    memset(bufferAux, 0, BLOCKSIZE);
    if(bwrite(nbloque, bufferAux) == -1){
        return -1;
    }

    return nbloque;
}

int liberar_bloque(unsigned int nbloque){
    struct superbloque SB;
    if(bread(posSB,&SB) == -1){
        return -1;
    }

    if(escribir_bit(nbloque, 0) == -1){
        return -1;
    }

    SB.cantBloquesLibres++;
    if(bwrite(posSB, &SB) == -1){
		return -1;
	}

    return nbloque;
}

int escribir_inodo(unsigned int ninodo, inodo_t inodo){
    struct superbloque SB;
    if(bread(posSB,&SB) == -1){
        return -1;
    }

    int nbloque = (ninodo/(BLOCKSIZE/INODOSIZE)) + SB.posPrimerBloqueAI;
    inodo_t inodos[BLOCKSIZE/INODOSIZE];
    
    if(bread(nbloque, inodos) == -1){
        return -1;
    }

    inodos[ninodo%(BLOCKSIZE/INODOSIZE)] = inodo;
    if(bwrite(nbloque, inodos) == -1){
		return -1;
	}
    
    return 0;
}

int leer_inodo(unsigned int ninodo, inodo_t *inodo){
    struct superbloque SB;
    if(bread(posSB, &SB) == -1){
        return -1;
    }

    int nBloque = (ninodo/(BLOCKSIZE/INODOSIZE)) + SB.posPrimerBloqueAI;
    inodo_t inodos[BLOCKSIZE/INODOSIZE];
    if(bread(nBloque, inodos) == -1){
        return -1;
    }

    *inodo = inodos [ninodo % (BLOCKSIZE/INODOSIZE)];
    return 0;
}

int reservar_inodo(unsigned char tipo, unsigned char permisos){
    struct superbloque SB;
    if(bread(posSB, &SB) == -1){
        return -1;
    }

	inodo_t inodo;
	unsigned int inodolibre = SB.posPrimerInodoLibre;
    if(leer_inodo(inodolibre, &inodo) == -1){
        return -1;
    }
    
	SB.posPrimerInodoLibre++;
    SB.cantInodosLibres--;
	inodo.tipo = tipo;
	inodo.permisos = permisos;
	inodo.nlinks = 1;
	inodo.tamEnBytesLog = 0;
	inodo.numBloquesOcupados = 0;
	inodo.atime = time(NULL); 
	inodo.mtime = time(NULL);
	inodo.ctime = time(NULL);

	for(int i = 0; i < 12; i++){
		inodo.punterosDirectos[i] = 0;
	}

	for(int i = 0; i < 3; i++){
		inodo.punterosIndirectos[i] = 0;
	}
    
    if(escribir_inodo(inodolibre, inodo) == -1){
        return -1;
    }

	if(bwrite(posSB, &SB) == -1){
        return -1;
    }

	return inodolibre;
}

int obtener_nrangoBL (inodo_t inodo, int nblogico, int *ptr){
    if(nblogico < DIRECTOS){
        *ptr = inodo.punterosDirectos[nblogico];
        return 0;
    }else if(nblogico < INDIRECTOS0){
        *ptr = inodo.punterosIndirectos[0];
        return 1;
    }else if(nblogico < INDIRECTOS1){
        *ptr = inodo.punterosIndirectos[1];
        return 2;
    }else if(nblogico < INDIRECTOS2){
        *ptr = inodo.punterosIndirectos[2];
        return 3;
    }else{
        *ptr = 0;
        perror("Error: ");
        return -1;
    }
}

int obtener_indice(int nblogico, int nivel_punteros){
    if(nblogico < DIRECTOS){
        return nblogico;
    } else if(nblogico < INDIRECTOS0){
        return nblogico-DIRECTOS;
    } else if(nblogico < INDIRECTOS1){
        if(nivel_punteros == 2){
            return(nblogico - INDIRECTOS0)/NPUNTEROS;
        } else if(nivel_punteros == 1){
            return(nblogico - INDIRECTOS0)%NPUNTEROS;
        }
    } else if(nblogico < INDIRECTOS2){
        if(nivel_punteros == 3){
            return(nblogico - INDIRECTOS1)/(NPUNTEROS*NPUNTEROS);
        } else if(nivel_punteros == 2){
            return((nblogico - INDIRECTOS1)%(NPUNTEROS*NPUNTEROS))/NPUNTEROS;
        } else if(nivel_punteros == 1){
            return((nblogico - INDIRECTOS1)%(NPUNTEROS*NPUNTEROS))%NPUNTEROS;
        }
    }
    perror("Error: ");
    return -1;
}

int traducir_bloque_inodo(int ninodo, int nblogico, int reservar){
    inodo_t inodo;
    int ptr, ptr_ant, salvar_inodo, nRangoBL, nivel_punteros, indice;
    int buffer[NPUNTEROS];
    if(leer_inodo(ninodo, &inodo) == -1){
        return -1;
    }

    ptr = 0;
    ptr_ant = 0;
    salvar_inodo = 0;
    nRangoBL = obtener_nrangoBL(inodo, nblogico, &ptr);
    if(nRangoBL == -1){
        return -1;
    }
    
    nivel_punteros = nRangoBL; //el nivel_punteros +alto es el que cuelga del inodo
    while(nivel_punteros > 0){ //iterar para cada nivel de indirectos
        if(ptr == 0){ //no cuelgan bloques de punteros
            if(reservar == 0){ //error lectura bloque inexistente
                return -1;
            } else{ //reservar bloques punteros y crear enlaces desde inodo hasta datos
                salvar_inodo = 1;
                ptr = reservar_bloque();
                if(ptr == -1){
                    return -1;
                }

                inodo.numBloquesOcupados++;
                inodo.ctime = time(NULL); //fecha actual
                if(nivel_punteros == nRangoBL){//el bloque cuelga directamente del inodo
                    inodo.punterosIndirectos[nRangoBL-1] = ptr; //(imprimirlo)
                    printf("[traducir_bloque_inodo()→ inodo.punterosIndirectos[%d] = %d (reservado BF %d para punteros_nivel%d)]\n", (nRangoBL-1), ptr, ptr, nRangoBL);
                } else{ //el bloque cuelga de otro bloque de punteros
                    buffer[indice] = ptr; // (imprimirlo)
                    printf("[traducir_bloque_inodo()→ punteros_nivel%d[%d] = %d (reservado BF %d para punteros_nivel%d)]\n", nivel_punteros+1, indice, ptr, ptr, nivel_punteros);
                    if(bwrite(ptr_ant, buffer) == -1){
                        return -1;
                    }
                }
            }
        }

        if(bread(ptr, buffer) == -1){
            return -1;
        }

        indice = obtener_indice(nblogico, nivel_punteros);
        if(indice == -1){
            return -1;
        }

        ptr_ant = ptr;             //guardamos el puntero
        ptr = buffer[indice];     //y lo desplazamos al siguiente nivel
        nivel_punteros--;
    }  //al salir de este bucle ya estamos al nivel de datos
    
    if(ptr == 0){ //no existe bloque de datos
        if(reservar == 0){
            return -1;
        } else{
            salvar_inodo = 1;
            ptr = reservar_bloque(); //de datos
            if(ptr == -1){
                return -1;
            }

            inodo.numBloquesOcupados++;
            inodo.ctime = time(NULL);
            if(nRangoBL == 0){
                inodo.punterosDirectos[nblogico] = ptr; //(imprimirlo)
                printf("[traducir_bloque_inodo()→ inodo.punterosDirectos[%d] = %d (reservado BF %d para BL %d)]\n", nblogico, ptr, ptr, nblogico);
            } else{
                buffer[indice] = ptr; //(imprimirlo)
                printf("[traducir_bloque_inodo()→ punteros_nivel%d[%d] = %d (reservado BF %d para BL %d)]\n", nivel_punteros+1, indice, ptr, ptr, nblogico);
                if(bwrite(ptr_ant, buffer) == -1){
                    return -1;
                }
            }
        }
    }
    
    if(salvar_inodo == 1){
        if(escribir_inodo(ninodo, inodo) == -1){  //sólo si lo hemos actualizado
            return -1;
        }
    }
    
    return ptr; //nbfisico
}

int liberar_inodo(unsigned int ninodo){
    int lbinodo = liberar_bloques_inodo(ninodo, 0);
    if(lbinodo == -1){
        return -1;
    }

    inodo_t inodo;
    if(leer_inodo(ninodo, &inodo) == -1){
        return -1;
    }

    inodo.numBloquesOcupados = inodo.numBloquesOcupados - lbinodo;
    inodo.tipo = 'l';
    struct superbloque SB;
	if(bread(posSB, &SB) == -1){
        return -1;
    }

	inodo.punterosDirectos[0] = SB.posPrimerInodoLibre;
    SB.posPrimerInodoLibre -= 1;
	SB.cantInodosLibres++;
    if(escribir_inodo(ninodo, inodo) == -1){
        return -1;
    }
    
    if(bwrite(posSB, &SB) == -1){
        return -1;
    }
    
	return lbinodo;
}

int liberar_bloques_inodo(unsigned int ninodo, unsigned int nblogico){
    inodo_t inodo;
    int nRangoBL, nivel_punteros, indice, ptr, nblog, UltimoBloqueLibre;
    unsigned char bufferAuxiliar[BLOCKSIZE];
    int bloques_punteros[3][NPUNTEROS];
    int indices[3];
    int ptr_nivel[3];
    int libres = 0;

    memset(bufferAuxiliar, 0, BLOCKSIZE);
    if(leer_inodo(ninodo, &inodo) == -1){
      return -1;
    }
    
    if(inodo.tamEnBytesLog == 0){
        return 0;
    }
    
    if((inodo.tamEnBytesLog % BLOCKSIZE) == 0){
        UltimoBloqueLibre = (inodo.tamEnBytesLog / BLOCKSIZE) - 1;
    } else{
        UltimoBloqueLibre = inodo.tamEnBytesLog / BLOCKSIZE;
    }
    
    printf("[liberar_bloques_inodo()→primer BL: %d, último BL: %d]\n", nblogico, UltimoBloqueLibre);
    ptr = 0;
    for(nblog = nblogico; nblog <= UltimoBloqueLibre; nblog++){
        nRangoBL = obtener_nrangoBL(inodo, nblog, &ptr);
        if(nRangoBL == -1){
            return -1;
        }

        nivel_punteros = nRangoBL;
        while(ptr > 0 && nivel_punteros > 0){
            if(bread(ptr, bloques_punteros[nivel_punteros - 1]) == -1){
                return -1;
            }

            indice = obtener_indice(nblog, nivel_punteros);
            if(indice == -1){
                return -1;
            }

            ptr_nivel[nivel_punteros - 1] = ptr;
            indices[nivel_punteros - 1] = indice;
            ptr = bloques_punteros[nivel_punteros - 1][indice];
            nivel_punteros--;
        }

        if(ptr > 0){
            if(liberar_bloque(ptr) == -1){
                return -1;
            }
            
            libres++;
            printf("[liberar_bloques_inodo()→liberado BF %d de datos correspondiente al BL %d]\n", ptr, nblog);
            if(nRangoBL == 0){
                inodo.punterosDirectos[nblog] = 0;
            }else{
                while(nivel_punteros < nRangoBL){
                    indice = indices[nivel_punteros];
                    bloques_punteros[nivel_punteros][indice] = 0;
                    ptr = ptr_nivel[nivel_punteros];
                    if(memcmp(bloques_punteros[nivel_punteros], bufferAuxiliar, BLOCKSIZE) == 0){
                        if(liberar_bloque(ptr) == -1){
                            return -1;
                        }

                        libres++;
                        nivel_punteros++;
                        printf("[liberar_bloques_inodo()→liberado BF %d de punteros de nivel %d correspondiente al BL %d]\n", ptr, nivel_punteros, nblog);
                        if(nivel_punteros == nRangoBL){
                            inodo.punterosIndirectos[nRangoBL - 1] = 0;
                        }
                    }else{
                        if(bwrite(ptr, bloques_punteros[nivel_punteros]) == -1){
                            return -1;
                        }
                        nivel_punteros = nRangoBL;
                    }
                }
            }
        }
    }
    printf("[liberar_bloques_inodo()→total bloques liberados: %d", libres);
    return libres; 
}