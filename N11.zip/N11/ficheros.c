#include "ficheros.h"

int mi_write_f(unsigned int ninodo, const void *buf_original, unsigned int offset, unsigned int nbytes){
	inodo_t inodo;
	if(leer_inodo (ninodo, &inodo) == -1){
		return -1;
	}
	
    if((inodo.permisos & 2) != 2){
		perror("Error: ");
		return -1;
	}
	
	unsigned int pbloque = offset/BLOCKSIZE;
	unsigned int ubloque = (offset + nbytes - 1)/BLOCKSIZE;
	unsigned char buf_bloque[BLOCKSIZE];
	int desp1 = offset % BLOCKSIZE;

	
	if(pbloque == ubloque){
		
		int bfisico = traducir_bloque_inodo(ninodo, pbloque, 1);
		if(bfisico == -1){
			return -1;
		}
		
		
        if (bread(bfisico, buf_bloque) == -1){
			return -1;
		}
		
		memcpy(buf_bloque + desp1, buf_original, nbytes);
		if (bwrite(bfisico, buf_bloque) == -1){
			return -1;
		}
	}else{
		//1
		int bfisico = traducir_bloque_inodo(ninodo, pbloque, 1);
		if(bfisico == -1){
			return -1;
		}
		
        if (bread(bfisico, buf_bloque) == -1){
			return -1;
		}
		
		memcpy(buf_bloque + desp1, buf_original, BLOCKSIZE - desp1);
		if (bwrite (bfisico, buf_bloque) == -1){
			return -1;
		}
		//2
		for(int i = pbloque + 1; i < ubloque; i++){
			bfisico = traducir_bloque_inodo(ninodo, i, 1);
			if(bfisico == -1){
				return -1;
			}
			
			if(bwrite(bfisico, buf_original + (BLOCKSIZE - desp1) + (i - pbloque - 1) * BLOCKSIZE) == -1){
				return -1;
			}
		}
		//3
		bfisico = traducir_bloque_inodo(ninodo, ubloque, 1);
		if(bfisico == -1){
			return -1;
		}
		
        if (bread(bfisico, buf_bloque) == -1){
			return -1;
		}
		
		int desp2 = (offset + nbytes - 1) % BLOCKSIZE;
		memcpy(buf_bloque, buf_original + (nbytes - desp2 - 1), desp2 + 1);
		if (bwrite (bfisico, buf_bloque) == -1){
			return -1;
		}
	}
	
	if(leer_inodo(ninodo, &inodo) == -1){
		return -1;
	}
	
	if((inodo.tamEnBytesLog < (offset + nbytes)) && (nbytes != 0)){
		inodo.tamEnBytesLog = offset+nbytes;
		inodo.ctime = time(NULL);
	}
	
    inodo.mtime = time(NULL);
    if(escribir_inodo(ninodo, inodo) == -1){
		return -1;
	}
	
    return nbytes;
}

int mi_read_f(unsigned int ninodo, void *buf_original, unsigned int offset, unsigned int nbytes){
	inodo_t inodo;
	if(leer_inodo (ninodo, &inodo) == -1){
		return -1;
	}
	
    if((inodo.permisos & 4) != 4){
		perror("Error: ");
		return -1;
	}
	
	if((offset + nbytes) >= inodo.tamEnBytesLog){
		nbytes = inodo.tamEnBytesLog - offset;
	}

	if(offset > inodo.tamEnBytesLog || inodo.tamEnBytesLog == 0 || nbytes == 0){
		return 0;
	}
	unsigned char buf_bloque[BLOCKSIZE];
	memset(buf_bloque,0,BLOCKSIZE);

	unsigned int pbloque = offset/BLOCKSIZE;
	unsigned int ubloque = (offset + nbytes - 1)/BLOCKSIZE;
	int bytes = 0;
	int desp1 = offset % BLOCKSIZE;
	
	if(pbloque == ubloque){
		int bfisico = traducir_bloque_inodo(ninodo, pbloque, 0);
		if(bfisico != -1){
			if(bread(bfisico, buf_bloque) == -1){
				return -1;
			}
			
			memcpy(buf_original, buf_bloque + desp1, nbytes);
		}
		bytes = nbytes;
	}else{
		//1
		int bfisico = traducir_bloque_inodo(ninodo, pbloque, 0);
		if(bfisico != -1){
			if(bread(bfisico, buf_bloque) == -1){
				return -1;
			}

			memcpy(buf_original, buf_bloque + desp1, bytes);
		}

		bytes = BLOCKSIZE - desp1;
		//2
		for(int i = pbloque + 1; i < ubloque; i++){
			bfisico = traducir_bloque_inodo(ninodo, i, 0);
			if(bfisico != -1){
				if (bread(bfisico, buf_bloque) == -1){
					return -1;
				}
				
				memcpy(buf_original + (BLOCKSIZE - desp1) + (i - pbloque - 1) * BLOCKSIZE, buf_bloque, BLOCKSIZE);
			}
			
			bytes += BLOCKSIZE;
		}
		//3
		int desp2 = (offset + nbytes - 1) % BLOCKSIZE;
		bfisico = traducir_bloque_inodo(ninodo, ubloque, 0);
		if(bfisico == -1){
			if (bread(bfisico, buf_bloque) == -1){
				return -1;
			}	
			
			memcpy(buf_bloque, buf_original + (nbytes - desp2 - 1), desp2 + 1);
		}

		bytes += desp2 + 1;
	}

	if(leer_inodo(ninodo, &inodo) == -1){
		return -1;
	}
	
	inodo.atime = time(NULL);
    if(escribir_inodo(ninodo, inodo) == -1){
		return -1;
	}

    return bytes;
}

int mi_stat_f(unsigned int ninodo, stat_t *p_stat){
	inodo_t inodo;
	if(leer_inodo(ninodo, &inodo) == -1){
		return -1;
	}
	
	p_stat->tipo = inodo.tipo;
	p_stat->permisos = inodo.permisos;
	p_stat->atime = inodo.atime;
	p_stat->mtime = inodo.mtime;
	p_stat->ctime = inodo.ctime;
	p_stat->nlinks = inodo.nlinks;
	p_stat->tamEnBytesLog = inodo.tamEnBytesLog;
	p_stat->numBloquesOcupados = inodo.numBloquesOcupados;

	return 0;
}

int mi_chmod_f(unsigned int ninodo, unsigned char permisos){
	if((permisos < 0) || (permisos > 7)){
		perror("Error: ");
		return -1;
	}
	
	inodo_t inodo;
	if(leer_inodo(ninodo, &inodo) == -1){
		return -1;
	}
	
	inodo.permisos = permisos;
	inodo.ctime = time(NULL);
	if(escribir_inodo(ninodo, inodo) == -1){
		return -1;
	}
	
	return 0;
}

int mi_truncar_f(unsigned int ninodo, unsigned int nbytes) {
    inodo_t inodo;
	if(leer_inodo(ninodo, &inodo) == -1){
		return -1;
	}

	int nblogico=0;
	if((inodo.permisos & 2) != 2) {
		printf("No tiene permiso de escritura\n"); 
		return -1; 
	}

	if(inodo.tamEnBytesLog < nbytes){
		printf("No se puede truncar más allá del EOF\n");
		return -1;
	}
	
	if(nbytes % BLOCKSIZE == 0){
		nblogico = nbytes/BLOCKSIZE;
	}else{
		nblogico = (nbytes/BLOCKSIZE) + 1;
	}

	int liberados = liberar_bloques_inodo(ninodo,nblogico);
	if(liberados == -1){
		return -1;
	}

	if(leer_inodo(ninodo, &inodo) == -1){
		return -1;
	}

	inodo.mtime = time(NULL);
	inodo.ctime = time(NULL);
	inodo.tamEnBytesLog = nbytes;
	inodo.numBloquesOcupados = inodo.numBloquesOcupados - liberados;
	if(escribir_inodo(ninodo, inodo) == -1){
		return -1;
	}

	return liberados;
}