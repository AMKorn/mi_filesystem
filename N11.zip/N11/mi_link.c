#include "directorios.h"

int main(int argc, char **argv){
    if (argc != 4){
        printf("Sintaxis correcta: ./mi_link <disco> </ruta_fichero_original> </ruta_enlace>\n");
        return -1;
    }

    if(bmount(argv[1]) == -1){
        return -1;
    }

    if(mi_link(argv[2],argv[3]) == 0){
        printf("Enlace creado correctamente.\n");
    }
    else{
        printf("Error en mi_link.\n");
    }

    if(bumount(argv[1]) == -1){
		return -1;
	}
    return 0;
}