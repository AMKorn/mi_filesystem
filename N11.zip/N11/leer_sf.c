#include "ficheros_basico.h"

int main(int argc, char const *argv[]){
    if (argc != 2){
        perror("Error: ");
        return -1;
    }

    //montamos el dispositivo
    if (bmount(argv[1]) == -1){
        return -1;
    }

    struct superbloque SB;

    if (bread(posSB, &SB) == -1){
        return -1;
    }

    printf("DATOS DEL SUPERBLOQUE\n");
    printf("posPrimerBloqueMB = %d\n", SB.posPrimerBloqueMB);
    printf("posUltimoBloqueMB = %d\n", SB.posUltimoBloqueMB);
    printf("posPrimerBloqueAI = %d\n", SB.posPrimerBloqueAI);
    printf("posUltimoBloqueAI = %d\n", SB.posUltimoBloqueAI);
    printf("posPrimerBloqueDatos = %d\n", SB.posPrimerBloqueDatos);
    printf("posUltimoBloqueDatos = %d\n", SB.posUltimoBloqueDatos);
    printf("posInodoRaiz = %d\n", SB.posInodoRaiz);
    printf("posPrimerInodoLibre = %d\n", SB.posPrimerInodoLibre);
    printf("cantBloquesLibres = %d\n", SB.cantBloquesLibres);
    printf("cantInodosLibres = %d\n", SB.cantInodosLibres);
    printf("totBloques = %d\n", SB.totBloques);
    printf("totInodos = %d\n", SB.totInodos);
    printf("sizeof struct superbloque = %ld\n", sizeof(struct superbloque));
    printf("sizeof struct inodo = %ld\n", sizeof(inodo_t));

    //desmontamos el dispositivo
    if (bumount(argv[1]) == -1){
        return -1;
    }

    return 0;
}