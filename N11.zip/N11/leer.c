#include "ficheros.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>

int main(int argc, char **argv){
    if(argc != 3){
        printf("Numero de parametros incorrectos\n");
        return -1;
    }

    if(bmount(argv[1]) == -1){
        printf("\nFallo al montar el disco\n");
		return -1;
    }

    inodo_t inodo;
    if (leer_inodo(atoi(argv[2]), &inodo) == -1){
        return -1;
    }

    if((inodo.permisos & 4) != 4){
        printf("\n No tiene permiso de lectura\n");
        return -1;
    }
	
    char buffer[BLOCKSIZE];
    memset(buffer, 0, BLOCKSIZE);

    int offset = 0;
    int bytesLeidos = 0;
    int bytesTotales = inodo.tamEnBytesLog;

    while (offset < bytesTotales){
        memset(buffer, 0, BLOCKSIZE);
        bytesLeidos = mi_read_f(atoi(argv[2]), buffer, offset, BLOCKSIZE);
		if(bytesLeidos == -1){
			return -1;
		}
		
        if(write(1, buffer, bytesLeidos) == -1){
			return -1;
		}

        offset += bytesLeidos;
    }

    fprintf(stderr, "\n Bytes leidos: %d", offset);
    fprintf(stderr, "\n Tamaño bytes logicos: %d \n", bytesTotales);
    if (bumount(argv[1]) == -1){
        return -1;
    }
	
}
