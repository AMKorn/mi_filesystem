#include "directorios.h"

int extraer_camino(const char *camino, char *inicial, char *final)
{
	if (camino[0] != '/')
	{
		return -1;
	}

	int i = 1;
	while ((camino[i] != '/') && (camino[i] != '\0'))
	{
		inicial[i - 1] = camino[i];
		i++;
	}

	if (i == strlen(camino))
	{
		final = "\0";
		return 0; //Fichero
	}

	for (int j = 0; i < strlen(camino); j++, i++)
	{
		final[j] = camino[i];
	}

	return 1; //Directorio
}

int buscar_entrada(const char *camino_parcial, unsigned int *p_inodo_dir, unsigned int *p_inodo, unsigned int *p_entrada, int reservar, unsigned char permisos)
{
	if (strcmp(camino_parcial, "/") == 0)
	{
		*p_inodo = 0;
		*p_entrada = 0;
		return 0;
	}

	char inicial[60], final[strlen(camino_parcial)];
	memset(inicial, 0, 60);
	memset(final, 0, strlen(camino_parcial));
	int ec = extraer_camino(camino_parcial, inicial, final);
	if (ec == -1)
	{
		return ERROR_EXTRAER_CAMINO;
	}

	printf("[buscar_entrada()→ inicial: %s, final: %s, reservar: %d]\n", inicial, final, reservar);
	inodo_t inodo;
	if (leer_inodo(*p_inodo_dir, &inodo) == -1)
	{
		return ERROR_LEER_INODO;
	}

	if ((inodo.permisos & 4) != 4)
	{
		return ERROR_PERMISO_LECTURA;
	}

	struct entrada entr;
	int numentradas = inodo.tamEnBytesLog / sizeof(struct entrada);
	int nentrada = 0;
	if (numentradas > 0)
	{
		if (mi_read_f(*p_inodo_dir, &entr, nentrada * sizeof(struct entrada), sizeof(struct entrada)) == -1)
		{
			return ERROR_LECTURA;
		}

		while ((nentrada < numentradas) && (strcmp(inicial, entr.nombre) != 0))
		{
			nentrada++;
			if (mi_read_f(*p_inodo_dir, &entr, nentrada * sizeof(struct entrada), sizeof(struct entrada)) == -1)
			{
				return ERROR_LECTURA;
			}
		}
	}

	if (nentrada == numentradas)
	{
		switch (reservar)
		{
		case 0:
			return ERROR_NO_EXISTE_ENTRADA_CONSULTA;
			break;
		case 1:
			if (inodo.tipo == 'f')
			{
				return ERROR_NO_SE_PUEDE_CREAR_ENTRADA_EN_UN_FICHERO;
			}

			if ((inodo.permisos & 2) != 2)
			{
				return ERROR_PERMISO_ESCRITURA;
			}

			int inR;
			strcpy(entr.nombre, inicial);
			if (ec == 1)
			{
				if (strcmp(final, "/") != 0)
				{
					return ERROR_NO_EXISTE_DIRECTORIO_INTERMEDIO;
				}

				if ((inR = reservar_inodo('d', permisos)) == -1)
				{
					return ERROR_RESERVAR_INODO;
				}
			}
			else
			{
				if ((inR = reservar_inodo('f', permisos)) == -1)
				{
					return ERROR_RESERVAR_INODO;
				}
			}

			entr.ninodo = inR;
			if (mi_write_f(*p_inodo_dir, &entr, nentrada * sizeof(struct entrada), sizeof(struct entrada)) == -1)
			{
				if (liberar_inodo(entr.ninodo) == -1)
				{
					return ERROR_LIBERAR_INODO;
				}

				return ERROR_ESCRITURA;
			}
		}
	}

	if (strcmp(final, "/") == 0 || ec == 0)
	{
		if (nentrada < numentradas && reservar == 1)
		{
			return ERROR_ENTRADA_YA_EXISTENTE;
		}

		*p_inodo = entr.ninodo;
		*p_entrada = nentrada;
		printf("[buscar_entrada()→ entrada.nombre: %s, entrada.ninodo: %d]\n", entr.nombre, entr.ninodo);
		printf("[buscar_entrada()→ reservado inodo %d tipo d con permisos %d]\n", entr.ninodo, permisos);
		return 0;
	}

	*p_inodo_dir = entr.ninodo;
	return buscar_entrada(final, p_inodo_dir, p_inodo, p_entrada, reservar, permisos);
}

int mi_creat(const char *camino, unsigned char permisos)
{
	unsigned int p_inodo_dir = 0, p_inodo = 0, p_entrada = 0;
	int be = buscar_entrada(camino, &p_inodo_dir, &p_inodo, &p_entrada, 1, permisos);
	if (be < 0)
	{
		switch (be)
		{
		case ERROR_ENTRADA_YA_EXISTENTE:
			printf("Ya existe la entrada \"%s\"\n", camino);
			break;
		case ERROR_ESCRITURA:
			printf("Error al escribir la entrada");
			break;
		case ERROR_EXTRAER_CAMINO:
			printf("Error en extraer camino \"%s\"\n", camino);
			break;
		case ERROR_LECTURA:
			printf("\"%s\" Error lectura entrada\n", camino);
			break;
		case ERROR_LEER_INODO:
			printf("Error al leer inodo\n");
			break;
		case ERROR_LIBERAR_INODO:
			printf("Error al liberar un inodo\n");
			break;
		case ERROR_NO_EXISTE_DIRECTORIO_INTERMEDIO:
			printf("No existe directorio intermedio a \"%s\"\n", camino);
			break;
		case ERROR_NO_EXISTE_ENTRADA_CONSULTA:
			printf("No existe la entrada a consultar \"%s\"\n", camino);
			break;
		case ERROR_NO_SE_PUEDE_CREAR_ENTRADA_EN_UN_FICHERO:
			printf("No se puede crear entrada en un fichero\n");
			break;
		case ERROR_PERMISO_ESCRITURA:
			printf("No tiene permisos de escritura\n");
			break;
		case ERROR_PERMISO_LECTURA:
			printf("No tiene permisos de lectura\n");
			break;
		case ERROR_RESERVAR_INODO:
			printf("\"%s\" Error en reservar inodo\n", camino);
			break;
		}
		puts("Error en mi_creat.");
		return -1;
	}

	return 0;
}

int mi_dir(const char *camino, char *buffer, int tipo)
{
	unsigned int p_inodo_dir = 0, p_inodo = 0, p_entrada = 0;
	int be = buscar_entrada(camino, &p_inodo_dir, &p_inodo, &p_entrada, 0, 0);
	if (be < 0)
	{
		switch (be)
		{
		case ERROR_ENTRADA_YA_EXISTENTE:
			printf("Ya existe la entrada \"%s\"\n", camino);
			break;
		case ERROR_ESCRITURA:
			printf("Error al escribir la entrada");
			break;
		case ERROR_EXTRAER_CAMINO:
			printf("Error en extraer camino\"%s\"\n", camino);
			break;
		case ERROR_LECTURA:
			printf("\"%s\" Error lectura entrada\n", camino);
			break;
		case ERROR_LEER_INODO:
			printf("Error al leer inodo\n");
			break;
		case ERROR_LIBERAR_INODO:
			printf("Error al liberar un inodo\n");
			break;
		case ERROR_NO_EXISTE_DIRECTORIO_INTERMEDIO:
			printf("No existe directorio intermedio a \"%s\"\n", camino);
			break;
		case ERROR_NO_EXISTE_ENTRADA_CONSULTA:
			printf("No existe la entrada a consultar \"%s\"\n", camino);
			break;
		case ERROR_NO_SE_PUEDE_CREAR_ENTRADA_EN_UN_FICHERO:
			printf("No se puede crear entrada en un fichero\n");
			break;
		case ERROR_PERMISO_ESCRITURA:
			printf("No tiene permisos de escritura\n");
			break;
		case ERROR_PERMISO_LECTURA:
			printf("No tiene permisos de lectura\n");
			break;
		case ERROR_RESERVAR_INODO:
			printf("\"%s\" Error en reservar inodo\n", camino);
			break;
		}
		puts("Error en mi_dir");
		return -1;
	}

	inodo_t inodo;
	if (leer_inodo(p_inodo, &inodo) == -1)
	{
		return -1;
	}

	struct entrada entrada;
	if (inodo.tipo == 'f'){
		return -1;
	}

	if (inodo.tipo != 'd' && inodo.permisos & 4)
	{
		return -1;
	}

	int numEntradas = inodo.tamEnBytesLog / sizeof(struct entrada);
	int nentrada = 0;
	printf("Total: %d\n", numEntradas);
	if (tipo == 1)
	{
		printf("Tipo\tPermisos\tmTime\t\t\tTamaño\t   Nombre\n");
	}
	printf("------------------------------------------------------------------\n");
	while (nentrada < numEntradas)
	{
		if (mi_read_f(p_inodo, &entrada, nentrada * sizeof(struct entrada), sizeof(struct entrada)) == -1)
		{
			return -1;
		}

		if (tipo == 1)
		{
			if (leer_inodo(entrada.ninodo, &inodo) == -1)
			{
				return -1;
			}

			if (inodo.tipo == 'd')
			{
				strcat(buffer, "d");
			}
			else
			{
				strcat(buffer, "f");
			}

			strcat(buffer, "\t");
			if (inodo.permisos & 4)
			{
				strcat(buffer, "r");
			}
			else
			{
				strcat(buffer, "-");
			}

			if (inodo.permisos & 2)
			{
				strcat(buffer, "w");
			}
			else
			{
				strcat(buffer, "-");
			}

			if (inodo.permisos & 1)
			{
				strcat(buffer, "x");
			}
			else
			{
				strcat(buffer, "-");
			}

			strcat(buffer, "\t\t");

			struct tm *tm;
			char tmp[100];
			tm = localtime(&inodo.mtime);
			sprintf(tmp, "%d-%02d-%02d %02d:%02d:%02d\t", tm->tm_year + 1900, tm->tm_mon + 1, tm->tm_mday, tm->tm_hour, tm->tm_min, tm->tm_sec);
			strcat(buffer, tmp);

			char buffer1[10];
			snprintf(buffer1, 10, "%d", inodo.tamEnBytesLog);
			strcat(buffer, buffer1);

			strcat(buffer, "\t   ");
		}

		strcat(buffer, entrada.nombre);
		strcat(buffer, "\n");
		nentrada++;
	}

	return numEntradas;
}

int mi_chmod(const char *camino, unsigned char permisos)
{
	unsigned int p_inodo_dir = 0, p_inodo = 0, p_entrada = 0;
	int be = buscar_entrada(camino, &p_inodo_dir, &p_inodo, &p_entrada, 0, permisos);
	if (be < 0)
	{
		switch (be)
		{
		case ERROR_ENTRADA_YA_EXISTENTE:
			printf("Ya existe la entrada \"%s\"\n", camino);
			break;
		case ERROR_ESCRITURA:
			printf("Error al escribir la entrada");
			break;
		case ERROR_EXTRAER_CAMINO:
			printf("Error en extraer camino \"%s\"\n", camino);
			break;
		case ERROR_LECTURA:
			printf("\"%s\" Error lectura entrada\n", camino);
			break;
		case ERROR_LEER_INODO:
			printf("Error al leer inodo\n");
			break;
		case ERROR_LIBERAR_INODO:
			printf("Error al liberar un inodo\n");
			break;
		case ERROR_NO_EXISTE_DIRECTORIO_INTERMEDIO:
			printf("No existe directorio intermedio a \"%s\"\n", camino);
			break;
		case ERROR_NO_EXISTE_ENTRADA_CONSULTA:
			printf("No existe la entrada a consultar \"%s\"\n", camino);
			break;
		case ERROR_NO_SE_PUEDE_CREAR_ENTRADA_EN_UN_FICHERO:
			printf("No se puede crear entrada en un fichero\n");
			break;
		case ERROR_PERMISO_ESCRITURA:
			printf("No tiene permisos de escritura\n");
			break;
		case ERROR_PERMISO_LECTURA:
			printf("No tiene permisos de lectura\n");
			break;
		case ERROR_RESERVAR_INODO:
			printf("\"%s\" Error en reservar inodo\n", camino);
			break;
		}
		puts("Error en mi_chmod");
		return -1;
	}

	if (mi_chmod_f(p_inodo, permisos) == -1)
	{
		return -1;
	}

	return 0;
}

int mi_stat(const char *camino, stat_t *p_stat)
{
	unsigned int p_inodo_dir = 0, p_inodo = 0, p_entrada = 0;
	int be = buscar_entrada(camino, &p_inodo_dir, &p_inodo, &p_entrada, 0, 0);
	if (be < 0)
	{
		switch (be)
		{
		case ERROR_ENTRADA_YA_EXISTENTE:
			printf("Ya existe la entrada \"%s\"\n", camino);
			break;
		case ERROR_ESCRITURA:
			printf("Error al escribir la entrada");
			break;
		case ERROR_EXTRAER_CAMINO:
			printf("Error en extraer camino\"%s\"\n", camino);
			break;
		case ERROR_LECTURA:
			printf("\"%s\" Error lectura entrada\n", camino);
			break;
		case ERROR_LEER_INODO:
			printf("Error al leer inodo\n");
			break;
		case ERROR_LIBERAR_INODO:
			printf("Error al liberar un inodo\n");
			break;
		case ERROR_NO_EXISTE_DIRECTORIO_INTERMEDIO:
			printf("No existe directorio intermedio a \"%s\"\n", camino);
			break;
		case ERROR_NO_EXISTE_ENTRADA_CONSULTA:
			printf("No existe la entrada a consultar \"%s\"\n", camino);
			break;
		case ERROR_NO_SE_PUEDE_CREAR_ENTRADA_EN_UN_FICHERO:
			printf("No se puede crear entrada en un fichero\n");
			break;
		case ERROR_PERMISO_ESCRITURA:
			printf("No tiene permisos de escritura\n");
			break;
		case ERROR_PERMISO_LECTURA:
			printf("No tiene permisos de lectura\n");
			break;
		case ERROR_RESERVAR_INODO:
			printf("\"%s\" Error en reservar inodo\n", camino);
			break;
		}
		puts("Error en mi_stat");
		return -1;
	}
	else
	{
		if (mi_stat_f(p_inodo, p_stat) == -1)
		{
			return -1;
		}
	}
	return 0;
}

int mi_read(const char *camino, void *buf, unsigned int offset, unsigned int nbytes)
{
	unsigned int p_inodo_dir = 0, p_inodo = 0, p_entrada = 0;
	int i = 0;
	while (i < num && strcmp(UltimaEntradaLectura[i].camino, "") != 0 && strcmp(camino, UltimaEntradaLectura[i].camino) != 0)
	{
		i++;
	}

	if (i < num && strcmp(camino, UltimaEntradaLectura[i].camino) == 0)
	{
		p_inodo = UltimaEntradaLectura[i].p_inodo;
	}
	else
	{
		int be = buscar_entrada(camino, &p_inodo_dir, &p_inodo, &p_entrada, 0, 0);
		if (be < 0)
		{
			switch (be)
			{
			case ERROR_ENTRADA_YA_EXISTENTE:
				printf("Ya existe la entrada \"%s\"\n", camino);
				break;
			case ERROR_ESCRITURA:
				printf("Error al escribir la entrada");
				break;
			case ERROR_EXTRAER_CAMINO:
				printf("Error en extraer camino\"%s\"\n", camino);
				break;
			case ERROR_LECTURA:
				printf("\"%s\" Error lectura entrada\n", camino);
				break;
			case ERROR_LEER_INODO:
				printf("Error al leer inodo\n");
				break;
			case ERROR_LIBERAR_INODO:
				printf("Error al liberar un inodo\n");
				break;
			case ERROR_NO_EXISTE_DIRECTORIO_INTERMEDIO:
				printf("No existe directorio intermedio a \"%s\"\n", camino);
				break;
			case ERROR_NO_EXISTE_ENTRADA_CONSULTA:
				printf("No existe la entrada a consultar \"%s\"\n", camino);
				break;
			case ERROR_NO_SE_PUEDE_CREAR_ENTRADA_EN_UN_FICHERO:
				printf("No se puede crear entrada en un fichero\n");
				break;
			case ERROR_PERMISO_ESCRITURA:
				printf("No tiene permisos de escritura\n");
				break;
			case ERROR_PERMISO_LECTURA:
				printf("No tiene permisos de lectura\n");
				break;
			case ERROR_RESERVAR_INODO:
				printf("\"%s\" Error en reservar inodo\n", camino);
				break;
			}
			return -1;
		}

		if (strcmp(UltimaEntradaLectura[num - 1].camino, "") == 0)
		{
			int j = 0;
			while (strcmp(UltimaEntradaLectura[j].camino, "") != 0)
			{
				j++;
			}
			strcpy(UltimaEntradaLectura[j].camino, camino);
			UltimaEntradaLectura[j].p_inodo = p_inodo;
		}
		else
		{
			int j = 0, k = 1;
			while (k < num)
			{
				strcpy(UltimaEntradaLectura[j].camino, UltimaEntradaEscritura[k].camino);
				UltimaEntradaLectura[j].p_inodo = UltimaEntradaEscritura[k].p_inodo;
				j++;
				k++;
			}
			strcpy(UltimaEntradaLectura[j].camino, camino);
			UltimaEntradaLectura[j].p_inodo = p_inodo;
		}
	}

	inodo_t inodo;
	if (leer_inodo(p_inodo, &inodo) == -1)
	{
		return -1;
	}

	if (inodo.tipo != 'f')
	{
		return -1;
	}

	if ((inodo.permisos & 4) != 4)
	{
		printf("\nError: No tiene permisos de lectura\n");
		return 0;
	}

	return mi_read_f(p_inodo, buf, offset, nbytes);
}

int mi_write(const char *camino, const void *buf, unsigned int offset, unsigned int nbytes)
{
	unsigned int p_inodo_dir = 0, p_inodo = 0, p_entrada = 0;
	int i = 0;
	while (i < num && strcmp(UltimaEntradaLectura[i].camino, "") != 0 && strcmp(camino, UltimaEntradaEscritura[i].camino) != 0)
	{
		i++;
	}

	if (i < num && strcmp(camino, UltimaEntradaEscritura[i].camino) == 0)
	{
		p_inodo = UltimaEntradaLectura->p_inodo;
	}
	else
	{
		int be = buscar_entrada(camino, &p_inodo_dir, &p_inodo, &p_entrada, 0, 0);
		if (be < 0)
		{
			switch (be)
			{
			case ERROR_ENTRADA_YA_EXISTENTE:
				printf("Ya existe la entrada \"%s\"\n", camino);
				break;
			case ERROR_ESCRITURA:
				printf("Error al escribir la entrada");
				break;
			case ERROR_EXTRAER_CAMINO:
				printf("Error en extraer camino\"%s\"\n", camino);
				break;
			case ERROR_LECTURA:
				printf("\"%s\" Error lectura entrada\n", camino);
				break;
			case ERROR_LEER_INODO:
				printf("Error al leer inodo\n");
				break;
			case ERROR_LIBERAR_INODO:
				printf("Error al liberar un inodo\n");
				break;
			case ERROR_NO_EXISTE_DIRECTORIO_INTERMEDIO:
				printf("No existe directorio intermedio a \"%s\"\n", camino);
				break;
			case ERROR_NO_EXISTE_ENTRADA_CONSULTA:
				printf("No existe la entrada a consultar \"%s\"\n", camino);
				break;
			case ERROR_NO_SE_PUEDE_CREAR_ENTRADA_EN_UN_FICHERO:
				printf("No se puede crear entrada en un fichero\n");
				break;
			case ERROR_PERMISO_ESCRITURA:
				printf("No tiene permisos de escritura\n");
				break;
			case ERROR_PERMISO_LECTURA:
				printf("No tiene permisos de lectura\n");
				break;
			case ERROR_RESERVAR_INODO:
				printf("\"%s\" Error en reservar inodo\n", camino);
				break;
			}
			return -1;
		}

		if (strcmp(UltimaEntradaLectura[num - 1].camino, "") == 0)
		{
			int j = 0;
			while (strcmp(UltimaEntradaLectura[j].camino, "") != 0)
			{
				j++;
			}
			strcpy(UltimaEntradaEscritura[j].camino, camino);
			UltimaEntradaEscritura[j].p_inodo = p_inodo;
		}
		else
		{
			int j = 0, k = 1;
			while (k < num)
			{
				strcpy(UltimaEntradaEscritura[j].camino, UltimaEntradaEscritura[k].camino);
				UltimaEntradaEscritura[j].p_inodo = UltimaEntradaEscritura[k].p_inodo;
				j++;
				k++;
			}
			strcpy(UltimaEntradaEscritura[j].camino, camino);
			UltimaEntradaEscritura[j].p_inodo = p_inodo;
		}
	}

	inodo_t inodo;
	if (leer_inodo(p_inodo, &inodo) == -1)
	{
		return -1;
	}

	if (inodo.tipo != 'f')
	{
		return -1;
	}

	if ((inodo.permisos & 2) != 2)
	{
		printf("\nError: No tiene permisos de escritura\n");
		return 0;
	}

	return mi_write_f(p_inodo, buf, offset, nbytes);
}

int mi_link(const char *camino1, const char *camino2)
{
	unsigned int p_inodo_dir = 0, p_inodo = 0, p_entrada = 0;
	int beo = buscar_entrada(camino1, &p_inodo_dir, &p_inodo, &p_entrada, 0, 0);
	if (beo < 0)
	{
		switch (beo)
		{
		case ERROR_ENTRADA_YA_EXISTENTE:
			printf("Ya existe la entrada \"%s\"\n", camino1);
			break;
		case ERROR_ESCRITURA:
			printf("Error al escribir la entrada");
			break;
		case ERROR_EXTRAER_CAMINO:
			printf("Error en extraer camino\"%s\"\n", camino1);
			break;
		case ERROR_LECTURA:
			printf("\"%s\" Error lectura entrada\n", camino1);
			break;
		case ERROR_LEER_INODO:
			printf("Error al leer inodo\n");
			break;
		case ERROR_LIBERAR_INODO:
			printf("Error al liberar un inodo\n");
			break;
		case ERROR_NO_EXISTE_DIRECTORIO_INTERMEDIO:
			printf("No existe directorio intermedio a \"%s\"\n", camino1);
			break;
		case ERROR_NO_EXISTE_ENTRADA_CONSULTA:
			printf("No existe la entrada a consultar \"%s\"\n", camino1);
			break;
		case ERROR_NO_SE_PUEDE_CREAR_ENTRADA_EN_UN_FICHERO:
			printf("No se puede crear entrada en un fichero\n");
			break;
		case ERROR_PERMISO_ESCRITURA:
			printf("No tiene permisos de escritura\n");
			break;
		case ERROR_PERMISO_LECTURA:
			printf("No tiene permisos de lectura\n");
			break;
		case ERROR_RESERVAR_INODO:
			printf("\"%s\" Error en reservar inodo\n", camino1);
			break;
		}
		puts("Error en mi_link (camino1)");
		return -1;
	}
	inodo_t inodo;
	if (leer_inodo(p_inodo, &inodo) == -1)
	{
		return -1;
	}
	if (inodo.tipo == 'd')
	{
		return -1;
	}

	unsigned int p_inodo_dir2 = 0, p_inodo2 = 0, p_entrada2 = 0;
	int bed = buscar_entrada(camino2, &p_inodo_dir2, &p_inodo2, &p_entrada2, 1, 6);
	if (bed < 0)
	{
		switch (bed)
		{
		case ERROR_ENTRADA_YA_EXISTENTE:
			printf("Ya existe la entrada \"%s\"\n", camino2);
			break;
		case ERROR_ESCRITURA:
			printf("Error al escribir la entrada");
			break;
		case ERROR_EXTRAER_CAMINO:
			printf("Error en extraer camino\"%s\"\n", camino2);
			break;
		case ERROR_LECTURA:
			printf("\"%s\" Error lectura entrada\n", camino2);
			break;
		case ERROR_LEER_INODO:
			printf("Error al leer inodo\n");
			break;
		case ERROR_LIBERAR_INODO:
			printf("Error al liberar un inodo\n");
			break;
		case ERROR_NO_EXISTE_DIRECTORIO_INTERMEDIO:
			printf("No existe directorio intermedio a \"%s\"\n", camino2);
			break;
		case ERROR_NO_EXISTE_ENTRADA_CONSULTA:
			printf("No existe la entrada a consultar \"%s\"\n", camino2);
			break;
		case ERROR_NO_SE_PUEDE_CREAR_ENTRADA_EN_UN_FICHERO:
			printf("No se puede crear entrada en un fichero\n");
			break;
		case ERROR_PERMISO_ESCRITURA:
			printf("No tiene permisos de escritura\n");
			break;
		case ERROR_PERMISO_LECTURA:
			printf("No tiene permisos de lectura\n");
			break;
		case ERROR_RESERVAR_INODO:
			printf("\"%s\" Error en reservar inodo\n", camino2);
			break;
		}
		puts("Error en mi_link (camino2)");
		return -1;
	}
	struct entrada ent;
	if (mi_read_f(p_inodo_dir2, &ent, p_entrada * sizeof(struct entrada), sizeof(struct entrada)) == -1)
	{
		printf("Error en mi_read.\n");
		return -1;
	}
	liberar_inodo(p_inodo2);
	ent.ninodo = p_inodo;
	if (mi_write_f(p_inodo_dir2, &ent, p_entrada * sizeof(struct entrada), sizeof(struct entrada)) == -1)
	{
		printf("Error en mi_write.\n");
		return -1;
	}
	inodo.nlinks++;
	inodo.ctime = time(NULL);
	escribir_inodo(p_inodo, inodo);
	return 0;
}

int mi_unlink(const char *camino)
{
	unsigned int p_inodo_dir = 0, p_inodo = 0, p_entrada = 0;
	int beo = buscar_entrada(camino, &p_inodo_dir, &p_inodo, &p_entrada, 0, 0);
	if (beo < 0)
	{
		switch (beo)
		{
		case ERROR_ENTRADA_YA_EXISTENTE:
			printf("Ya existe la entrada \"%s\"\n", camino);
			break;
		case ERROR_ESCRITURA:
			printf("Error al escribir la entrada");
			break;
		case ERROR_EXTRAER_CAMINO:
			printf("Error en extraer camino\"%s\"\n", camino);
			break;
		case ERROR_LECTURA:
			printf("\"%s\" Error lectura entrada\n", camino);
			break;
		case ERROR_LEER_INODO:
			printf("Error al leer inodo\n");
			break;
		case ERROR_LIBERAR_INODO:
			printf("Error al liberar un inodo\n");
			break;
		case ERROR_NO_EXISTE_DIRECTORIO_INTERMEDIO:
			printf("No existe directorio intermedio a \"%s\"\n", camino);
			break;
		case ERROR_NO_EXISTE_ENTRADA_CONSULTA:
			printf("No existe la entrada a consultar \"%s\"\n", camino);
			break;
		case ERROR_NO_SE_PUEDE_CREAR_ENTRADA_EN_UN_FICHERO:
			printf("No se puede crear entrada en un fichero\n");
			break;
		case ERROR_PERMISO_ESCRITURA:
			printf("No tiene permisos de escritura\n");
			break;
		case ERROR_PERMISO_LECTURA:
			printf("No tiene permisos de lectura\n");
			break;
		case ERROR_RESERVAR_INODO:
			printf("\"%s\" Error en reservar inodo\n", camino);
			break;
		}
		puts("Error en mi_link (camino1)");
		return -1;
	}
	inodo_t inodo;
	if (leer_inodo(p_inodo_dir, &inodo) == -1)
	{
		return -1;
	}
	int numEntradas = inodo.tamEnBytesLog / sizeof(struct entrada);
	if (numEntradas - 1 != p_entrada)
	{
		struct entrada ent;
		if (mi_read_f(p_inodo_dir, &ent, (numEntradas - 1) * sizeof(struct entrada), sizeof(struct entrada)) == -1)
		{
			return -1;
		}
		if (mi_write_f(p_inodo_dir, &ent, p_entrada * sizeof(struct entrada), sizeof(struct entrada)) == -1)
		{
			return -1;
		}
	}
	if (mi_truncar_f(p_inodo_dir, (numEntradas - 1) * sizeof(struct entrada)) == -1)
	{
		return -1;
	}
	if (leer_inodo(p_inodo, &inodo) == -1)
	{
		return -1;
	}
	if (inodo.nlinks == 1)
	{
		if (liberar_inodo(p_inodo) == -1)
		{
			return -1;
		}
	}
	else
	{
		inodo.ctime = time(NULL);
		inodo.nlinks--;
		if (escribir_inodo(p_inodo, inodo) == -1)
		{
			return -1;
		}
	}

	int i = 0;
	while (i < num && strcmp("", UltimaEntradaLectura[i].camino) != 0 && strcmp(camino, UltimaEntradaLectura[i].camino) != 0)
	{
		i++;
	}

	if (i < num && strcmp(camino, UltimaEntradaLectura[i].camino) == 0)
	{
		for (int j = i + 1; j < num && strcmp("", UltimaEntradaLectura[j].camino) != 0; i++, j++)
		{
			strcpy(UltimaEntradaLectura[i].camino, UltimaEntradaLectura[j].camino);
			UltimaEntradaLectura[i].p_inodo = UltimaEntradaLectura[j].p_inodo;
		}

		if (i < num)
		{
			strcpy(UltimaEntradaLectura[i].camino, "");
			UltimaEntradaLectura[i].p_inodo = 0;
		}
	}

	i = 0;
	while (i < num && strcmp("", UltimaEntradaEscritura[i].camino) != 0 && strcmp(camino, UltimaEntradaEscritura[i].camino) != 0)
	{
		i++;
	}

	if (i < num && strcmp(camino, UltimaEntradaEscritura[i].camino) == 0)
	{
		for (int j = i + 1; j < num && strcmp("", UltimaEntradaEscritura[j].camino) != 0; i++, j++)
		{
			strcpy(UltimaEntradaEscritura[i].camino, UltimaEntradaEscritura[j].camino);
			UltimaEntradaEscritura[i].p_inodo = UltimaEntradaEscritura[j].p_inodo;
		}

		if (i < num)
		{
			strcpy(UltimaEntradaEscritura[i].camino, "");
			UltimaEntradaEscritura[i].p_inodo = 0;
		}
	}

	return 0;
}
