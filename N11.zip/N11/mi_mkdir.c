#include "directorios.h"

int main(int argc, char **argv){
	if(argc != 4){
        printf("Sintaxis: ./mi_mkdir <disco> <permisos> </ruta>\n");
        return -1;
    }
	
	unsigned int permisos = atoi(argv[2]);
	if(permisos < 0 || permisos > 7){
		printf("Error: Permisos no validos\n");
	}
	
	if(bmount(argv[1]) == -1){
		return -1;
	}
	
	int ruta = strlen(argv[3])-1;
	if(mi_creat(argv[3], permisos) == 0){
		if(argv[3][ruta] == '/') { //es un directorio
			if(ruta > 1){
				printf("El directorio %s se ha creado correctamente\n", argv[3]);
			}
		} else { //es un fichero
			printf("El archivo %s se ha creado correctamente\n", argv[3]);
		}
	}
	
	if(bumount(argv[1]) == -1){
		return -1;
	}
	
	return 0;
}