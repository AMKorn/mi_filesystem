#include "directorios.h"

int main(int argc, char **argv){
	if(argc != 4){
        printf("Sintaxis: ./mi_touch <disco> <permisos> </ruta>\n");
        return -1;
    }
	int ruta = strlen(argv[3])-1;
	if (argv[3][ruta] == '/')
	{ //es un directorio
		printf("Error: %s no es un fichero\n", argv[3]);
		return -1;
	}
	
	
	unsigned int permisos = atoi(argv[2]);
	if(permisos < 0 || permisos > 7){
		printf("Error: Permisos no validos\n");
	}
	
	if(bmount(argv[1]) == -1){
		return -1;
	}
	
	
	if(mi_creat(argv[3], permisos) == -1){
        return -1;
	}
	
	if(bumount(argv[1]) == -1){
		return -1;
	}
	
	return 0;
}