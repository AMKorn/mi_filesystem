#include "ficheros.h"

int main(int argc, char **argv){

	if (argc != 4) {
		printf("Sintaxis: permitir <nombre_dispositivo> <ninodo> <permisos>\n");
		return -1;
	}
	
	if(bmount(argv[1]) == -1){
		return -1;
	}
	

	int ninodo = atoi(argv[2]);
	int permisos = atoi(argv[3]);
	if(mi_chmod_f(ninodo, permisos) == -1){
		return -1;
	}

	if(bumount() == -1){
		return -1;
	}
	
	return 0;
}	