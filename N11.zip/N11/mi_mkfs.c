#include "ficheros_basico.h"
//#include "bloques.h"
int main(int argc, char const *argv[]){
    if(argc == 3){
        unsigned int nbloque = atoi(argv[2]);
        if(bmount(argv[1]) == -1){
            printf("err1");
            return -1;
        }

        unsigned char buf[BLOCKSIZE];
        memset(buf, 0, BLOCKSIZE);
        for(int i = 0; i < nbloque; i++){
            if(bwrite(i, buf)==-1){
                printf("err2");
                return -1;
            }
        }

        if(initSB(nbloque, nbloque/4) == -1){
            return -1;
        }

        if(initMB() == -1){
            return -1;
        }
        
        if(initAI() == -1){
           return -1;
        }

        if(reservar_inodo('d', 7) == -1){
            return -1;
        }

        if(bumount()==-1){
            return -1;
        }
        
        return 0;
    }
    return -1;
    //sintaxis
}
