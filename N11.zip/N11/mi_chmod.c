#include "directorios.h"

int main(int argc, char **argv){
	if(argc != 4){
        printf("Sintaxis: ./mi_chmod <disco> <permisos> </ruta>\n");
        return -1;
    }
	
	unsigned int permisos = atoi(argv[2]);
	if(permisos < 0 || permisos > 7){
		printf("Error: Permisos no validos\n");
	}
	
	if(bmount(argv[1]) == -1){
		return -1;
	}
	
	if(mi_chmod(argv[3], permisos) == -1){
	    return -1;
	}
	
	if(bumount(argv[1]) == -1){
		return -1;
	}
	
	return 0;
}