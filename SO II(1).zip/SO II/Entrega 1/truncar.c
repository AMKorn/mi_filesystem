#include "ficheros.h"

int main(int argc, char **argv){

	if (argc != 4) {
		perror("Numero de parametros incorrectos en truncar \n\n ./truncar - nombre del disco - n inodo- n bytes a truncar");
		exit(-1);
	}
	
	
	int ninodo = atoi(argv[2]);
	int nbytes = atoi(argv[3]);
	
	struct inodo inodo;
	leer_inodo(ninodo, &inodo);
	bmount(argv[1]);
		
	mi_truncar_f(ninodo, nbytes);

	struct tm *ts;
    char atime[80];
    char mtime[80];
    char ctime[80];
	printf ("\nDatos inodo %d\n",ninodo); 
	leer_inodo(ninodo, &inodo);
	ts = localtime(&inodo.atime);
	strftime(atime, sizeof(atime), "%a %Y-%m-%d %H:%M:%S", ts);
	ts = localtime(&inodo.mtime);
	strftime(mtime, sizeof(mtime), "%a %Y-%m-%d %H:%M:%S", ts);
	ts = localtime(&inodo.ctime);
	strftime(ctime, sizeof(ctime), "%a %Y-%m-%d %H:%M:%S", ts);
	printf("TIPO: %c PERMISOS: %d\nNLINKS: %d TAMBYTESLOG: %d BLOQUES OCUPADOS: %d\nATIME: %s MTIME: %s CTIME: %s\n ",
	inodo.tipo, inodo.permisos, inodo.nlinks, inodo.tamEnBytesLog, inodo.numBloquesOcupados ,atime,mtime,ctime);
  	
	bumount();
	
	
}
