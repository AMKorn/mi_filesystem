#include <string.h>
#include <stdio.h>
#include "ficheros_basico.h"

unsigned char buffer[BLOCKSIZE];


int main(int argc, char **argv){
	ninodos= atoi(argv[2])/4;
	bmount(argv[1]);
	memset(buffer, 0, BLOCKSIZE); 
	initSB(atoi(argv[2]), ninodos);
	initMB();
	initAI();

    reservar_inodo ('d', 7);

	bumount();
	
}


