#include "ficheros_basico.h"


int tamMB(unsigned int nbloques){
	if(((nbloques/8) % BLOCKSIZE) == 0){ //si no sobran bytes
		return (nbloques/8)/BLOCKSIZE;
	} else {
		return ((nbloques/8)/BLOCKSIZE) +1;
	}
}

int tamAI(unsigned int ninodos){
	//determinar heurísticamente ninodos=nbloques/4, pero se pasa en mi_mkfs.c

	if(((ninodos * INODOSIZE) % BLOCKSIZE) == 0){ //si no sobran bytes
		return (ninodos * INODOSIZE) / BLOCKSIZE;
	} else {
		return ((ninodos * INODOSIZE) / BLOCKSIZE) +1;
	}
}

int initSB(unsigned int nbloques, unsigned int ninodos){
	struct superbloque SB;	
	SB.posPrimerBloqueMB = posSB+tamSB;
	
	SB.posUltimoBloqueMB = SB.posPrimerBloqueMB + tamMB(nbloques) - 1;
	
	SB.posPrimerBloqueAI = SB.posUltimoBloqueMB + 1;

	SB.posUltimoBloqueAI = SB.posPrimerBloqueAI  + tamAI(ninodos) - 1;

	SB.posPrimerBloqueDatos = SB.posUltimoBloqueAI + 1;

	SB.posUltimoBloqueDatos = nbloques - 1;

	SB.posInodoRaiz = 0;

	SB.posPrimerInodoLibre = 0;

	SB.cantBloquesLibres = nbloques;

	SB.cantInodosLibres = ninodos;

	SB.totBloques = nbloques;

	SB.totInodos= nbloques/4;
	
	if(bwrite(posSB, &SB)<0){
		return -1;
	}
}

/*
    Pondrá los bits que representan el super bloque, el mapa de bits y el array 
de inodos a 1, y los bits que representan a los datos a 0 para inicializarlos.
*/
int initMB(){
	struct superbloque SB;
	if(bread(posSB, &SB)<0){
		perror("Error en initMB: ");
		return -1;
	}
	int primerMB=SB.posPrimerBloqueMB;
	unsigned char buf [BLOCKSIZE];
	memset(buf, 0, BLOCKSIZE);
	for(int i=0; i<tamAI(ninodos); i++){
		if(bwrite(primerMB++, buf)<0){
			return -1;
		}
	}
	// Poner bits a 1 de SB, MB y AI 
	
	int i = 0;
	while (i <= SB.posUltimoBloqueAI) {
	    if(escribir_bit(i, 1)<0){
			perror("Error en initMB: ");
			return -1;
		}
	    i ++;
	}
	SB.cantBloquesLibres=SB.cantBloquesLibres - i;		
	if(bwrite(posSB, &SB)<0){
		perror("Error en initMB: ");
		return -1;
	}

}


int initAI(){
	struct inodo inodos [BLOCKSIZE];
	struct superbloque SB;
	if(bread(posSB, &SB)<0){
		perror("Error en initAI: ");
		return -1;
	}
	int posAI=SB.posPrimerBloqueAI;
	int contInodos = SB.posPrimerInodoLibre + 1;

	for (int i=SB.posPrimerBloqueAI; i<=SB.posUltimoBloqueAI; i++) {
		for (int j=0; j<(BLOCKSIZE / INODOSIZE); j++) {
    		inodos[j].tipo='l'; //libre
        	if (contInodos < SB.totInodos) {
        		inodos[j].punterosDirectos[0] = contInodos;
        		contInodos++;
			}else { //hemos llegado al último inodo
				inodos[j].punterosDirectos[0] = UINT_MAX;
   			}
		}
		if(bwrite(posAI++, inodos)<0){
			return -1;
		}
	}
	

}

int escribir_bit(unsigned int nbloque, unsigned int bit) {
	struct superbloque SB;
	if(bread(posSB, &SB)<0){
		perror("Error en escribir_bit: ");
		return -1;
	}
	unsigned char bufferMB[BLOCKSIZE];
	unsigned int posbyte = nbloque/8;
	unsigned int posbit= nbloque%8;
	unsigned int nbloqueMB= posbyte/BLOCKSIZE;
	unsigned int nbloqueabs=SB.posPrimerBloqueMB+nbloqueMB;
	posbyte=posbyte%BLOCKSIZE;
	unsigned char mascara=128;
	mascara >>= posbit;
	if(bread(nbloqueabs, bufferMB)<0){
		perror("Error en escribir_bit:");
		return -1;
	}
	
	if (bit) {
        bufferMB[posbyte] |= mascara;
    } else {
        bufferMB[posbyte] &= ~mascara;
    }
	if(bwrite(nbloqueabs, bufferMB)<0){
		perror("Error en escribir_bit:" );
		return -1;
	}
	return nbloque;
}



/*
    Devuelve el bit del Mapa de bits que se corresponde con el estado del bloque
cuyo número se le pasa por parámetros
*/
unsigned char leer_bit(unsigned int nbloque) {
    // Sacar la posicion del bloque del bit a leer
    struct superbloque SB;
	if(bread (posSB, &SB)<0){
		perror("error en leer_bit:");
		return -1;
	}
	unsigned int posbyte = nbloque / 8;
	unsigned int posbit = nbloque % 8;
	unsigned int nbloqueMB = posbyte / BLOCKSIZE;
	unsigned int nbloqueabs = SB.posPrimerBloqueMB + nbloqueMB;
	// Leer el bloque
	unsigned char bufferMB [BLOCKSIZE];
	if (bread (nbloqueabs, bufferMB)<0){
		perror("Error en leer_bit: ");
		return -1;
	}
	// Sacar el bit
	unsigned char mascara = 128; // 10000000
    mascara >>= posbit;           // desplazamiento de bits a la derecha
    mascara &= bufferMB[posbyte%BLOCKSIZE]; // operador AND para bits 
    mascara >>= 7-posbit;       // desplazamiento de bits a la derecha
    
    return mascara;
}

/*
    Busca el primer bloque libre y lo reserva. El valor que devuelve es la 
posición de ese bloque.
*/
int reservar_bloque(){
    unsigned int posBloque, posByte, posBit, nbloque;
    unsigned char mascara;
    struct superbloque SB; // Contendrá información del superbloque
    unsigned char bufferAux[BLOCKSIZE], bufferBloque[BLOCKSIZE];

    // Leemos el superbloque
    bread(posSB,&SB);
    
    // Si no quedan bloques libres, devolvemos -1
    if (!SB.cantBloquesLibres) { errno = ENOSPC; return -1; }

    // Si quedan, se localiza el primer bloque con un bit a 0 del mapa de bits
    memset(bufferAux, 255, BLOCKSIZE);
    posBloque = SB.posPrimerBloqueMB;

    bread(posBloque, bufferBloque);

    while (!memcmp(bufferBloque, bufferAux, BLOCKSIZE)){
        posBloque++;
        bread(posBloque, bufferBloque);
    }

    // Ahora localizamos el byte dentro del bloque
    posByte = 0;
    while (bufferBloque[posByte] == 255){
        posByte++;
    }

    // Por último buscamos el bit 0 dentro del byte
    mascara = 128;
    posBit = 0;
    while (mascara & bufferBloque[posByte]){
        posBit++;
        mascara >>= 1;
    }
 
    // Calculamos la posición del bloque dentro del SF
    nbloque = ((posBloque-SB.posPrimerBloqueMB)*BLOCKSIZE + posByte)*8 + posBit; 

    // Escribimos a 1 el bit que corresponde
    escribir_bit(nbloque, 1);

    // Actualizamos el contador de bloques libres en el SB
    SB.cantBloquesLibres -= 1;
    bwrite(posSB, &SB);

    // Inicializamos el bloque a 0
    memset(bufferAux, 0, BLOCKSIZE);
    bwrite(nbloque, bufferAux);

    // Retornamos la posición del bloque reservado
    return nbloque;
}

int liberar_bloque(unsigned int nbloque) {
    if(escribir_bit (nbloque, 0)<0){
		perror("Error en liberar_bloque:");
		return -1;
	}
    // Ahora hay un bloque más libre
    struct superbloque SB;
	if(bread(posSB, &SB)<0){
		perror("Error en liberar_bloque: ");
		return -1;
	}
    SB.cantBloquesLibres=SB.cantBloquesLibres + 1;
	if(bwrite(posSB, &SB)<0){
		perror("Error en lib_bloque: ");
		return -1;
	}
    return nbloque;
}


int escribir_inodo(unsigned int ninodo, struct inodo inodo) {
    struct superbloque SB;
	if(bread(posSB, &SB)<0){
		perror("error escribir inodod: ");
		return -1;	
	}
    
    // Sacamos en que bloque esta el ninodo
    int nBloque = (ninodo / BLOCKSIZE) + SB.posPrimerBloqueAI;
    
    struct inodo inodos[BLOCKSIZE/INODOSIZE];
    if(bread(nBloque, inodos)<0){
		perror("error en esc inodo:");
		return -1;       // Sacamos el bloque que queremos modificar
    }
    inodos[ninodo%(BLOCKSIZE/INODOSIZE)] = inodo;   // Metemos el inodo en el bloque que hemos sacado
    
    if(bwrite (nBloque, inodos)<0){
		perror("error en esc inodo:");
		return -1;
	}  // Volvemos a meter el bloque que hemos sacado, pero habiendole añadido el inodo nuevo   
}


int leer_inodo(unsigned int ninodo, struct inodo *inodo) {
    struct superbloque SB;
	bread (posSB, &SB);

	// Sacamos en que bloque esta el ninodo
    int nBloque = (ninodo / BLOCKSIZE) + SB.posPrimerBloqueAI;
    
    struct inodo inodos[BLOCKSIZE/INODOSIZE];
	bread(nBloque, inodos);
    *inodo = inodos [ninodo%(BLOCKSIZE/INODOSIZE)];
    return 0;    // Devuelve 0 si todo ha ido bien
}
 
int reservar_inodo(unsigned char tipo, unsigned char permisos) {
    struct superbloque SB;
	bread (posSB, &SB);

	struct inodo inodo;
	unsigned int inodolibre=SB.posPrimerInodoLibre;
	leer_inodo(inodolibre, &inodo);
	SB.posPrimerInodoLibre=inodo.punterosDirectos[0];
	   //completamos toda la info del inodo antes de escribirlo
	inodo.tipo=tipo;
	inodo.permisos=permisos;
	inodo.nlinks=1;
	inodo.tamEnBytesLog=0;
	inodo.numBloquesOcupados=0;
	inodo.atime=time(NULL); 
	inodo.mtime=time(NULL);
	inodo.ctime=time(NULL);
	//for que recorra el array de punteros directos e indirectos y los ponga a 0
	for (int i=0; i< 12; i++){
		inodo.punterosDirectos[i]=0;
	}
	for (int i=0; i< 3; i++){
		inodo.punterosIndirectos[i]=0;

	}
	SB.cantInodosLibres = SB.cantInodosLibres - 1;
	bwrite(posSB, &SB);	
	escribir_inodo (inodolibre, inodo); //escribimos el inodo

	return inodolibre;
	
}

int obtener_nrangoBL (struct inodo inodo, int nblogico, int* ptr){
	if (nblogico<DIRECTOS) {      
   		*ptr=inodo.punterosDirectos[nblogico];      
   		return 0;   
	}else if (nblogico<INDIRECTOS0) {          
   		*ptr=inodo.punterosIndirectos[0];        
   		return 1;      
	}else if (nblogico<INDIRECTOS1) {            
   		*ptr=inodo.punterosIndirectos[1];             
   		return 2;         
	}else if (nblogico<INDIRECTOS2) {               
   		*ptr=inodo.punterosIndirectos[2];                
   		return 3;           
	}else{               
   		*ptr=0;               
   		perror("Bloque lógico fuera de rango");        
   		return -1;
	}         
}

int obtener_indice (int nblogico, int nivel_punteros) { 
	if (nblogico<DIRECTOS) return nblogico;  
	else if (nblogico<INDIRECTOS0) return nblogico-DIRECTOS;    
	else if (nblogico<INDIRECTOS1){            
   		if( nivel_punteros==2){ 
      		return (nblogico-INDIRECTOS0)/ NPUNTEROS;            
   		}else if (nivel_punteros==1){ 
      		return (nblogico-INDIRECTOS0)% NPUNTEROS;           
   		}         
	}else if(nblogico<INDIRECTOS2) {               
   		if (nivel_punteros==3){
      		return (nblogico-INDIRECTOS1)/(NPUNTEROS*NPUNTEROS);               
   		}else if (nivel_punteros==2){       
      		return ((nblogico-INDIRECTOS1)%(NPUNTEROS*NPUNTEROS))/NPUNTEROS;              
   		}else if (nivel_punteros==1){     
      		return ((nblogico-INDIRECTOS1)%(NPUNTEROS*NPUNTEROS))%NPUNTEROS;    
  		}            
	}
}




int traducir_bloque_inodo (unsigned int ninodo,unsigned int nblogico,char reservar) {
	struct inodo inodo;
    int ptr, ptr_ant, salvar_inodo, nRangoBL, nivel_punteros, indice;   
    int buffer[NPUNTEROS];

	leer_inodo (ninodo, &inodo);
   	ptr = 0; 
    ptr_ant = 0;
    salvar_inodo = 0;
    nRangoBL = obtener_nrangoBL(inodo, nblogico, &ptr);
    nivel_punteros = nRangoBL;
    while (nivel_punteros>0){ //iterar para cada nivel de indirectos
      if (ptr==0) { //no cuelgan bloques de punteros
         if (reservar ==0) return -1; //error lectura bloque inexistente
         else { //reservar bloques punteros y crear enlaces desde inodo hasta datos
            salvar_inodo = 1;
            ptr = reservar_bloque(); //de punteros          
            inodo.numBloquesOcupados++;
            inodo.ctime = time(NULL); //fecha actual
            if (nivel_punteros == nRangoBL) { 
               //el bloque cuelga directamente del inodo
               inodo.punterosIndirectos[nRangoBL-1] = ptr;
			   printf("\nPTR: %d\n", ptr);
            } else {   //el bloque cuelga de otro bloque de punteros
               buffer[indice] = ptr;
			   printf("\nPTR: %d\n", ptr);
               bwrite(ptr_ant, buffer);                
         	}
		 }
		
         
      }
      bread(ptr, buffer); 
      indice = obtener_indice(nblogico, nivel_punteros);
      ptr_ant = ptr;
      ptr = buffer[indice];
      nivel_punteros--;    
   }   //al salir de este bucle ya estamos al nivel de datos
   
   if (ptr==0) { //no existe bloque de datos
      if (reservar==0) return -1;  //no existe bloque    
      else {
         salvar_inodo = 1;
         ptr = reservar_bloque(); //de datos
         inodo.numBloquesOcupados++;
         inodo.ctime = time(NULL);
         if (nRangoBL==0){
            inodo.punterosDirectos[nblogico] = ptr;
			printf("\nPTR: %d\n", ptr);
         }else {
            buffer[indice] = ptr;
			printf("\nPTR: %d\n", ptr);
            bwrite(ptr_ant, buffer);
         }
      }
   }

   if (salvar_inodo == 1) {
      escribir_inodo (ninodo, inodo);  //sólo si lo hemos actualizado
   }
   return ptr; //nbfisico
}
int liberar_inodo(unsigned int ninodo){
	struct inodo inodo;
	int liberados=liberar_bloques_inodo(ninodo, 0);
	
	leer_inodo(ninodo, &inodo);
	inodo.numBloquesOcupados= inodo.numBloquesOcupados-liberados;
	inodo.tipo='l';
	struct superbloque SB;
	bread (posSB, &SB);

	unsigned int inodolibre=SB.posPrimerInodoLibre;
	leer_inodo(inodolibre, &inodo);
	SB.posPrimerInodoLibre=inodo.punterosDirectos[0];
	SB.cantInodosLibres++;
	escribir_inodo(ninodo, inodo);
	bwrite(posSB, &SB);
	return ninodo;
}
int liberar_bloques_inodo(unsigned int ninodo, unsigned int nblogico){
	struct inodo inodo;
  int nRangoBL, nivel_punteros, indice, ptr, nblog, ultimoBL;
  unsigned char bufferAux[BLOCKSIZE];
  int bloques_punteros[3][NPUNTEROS];
  int ptr_nivel [3];   //punteros auxiliares a bloques
  int indices[3];    //indices auxiliares
  int liberados;

  memset(bufferAux, 0, BLOCKSIZE);
  liberados=0;
  leer_inodo(ninodo, &inodo);
	if (inodo.tamEnBytesLog==0) return 0;
  if((inodo.tamEnBytesLog%BLOCKSIZE)==0){
  	ultimoBL=inodo.tamEnBytesLog/BLOCKSIZE - 1;
	}
  else{
		ultimoBL=inodo.tamEnBytesLog/BLOCKSIZE;
	}
  ptr=0;
  for (nblog=nblogico; nblog<=ultimoBL; nblog++) {
    nRangoBL=obtener_nrangoBL(inodo,nblog,&ptr);
		if (nRangoBL < 0) return -1;
    nivel_punteros=nRangoBL;
  	while (ptr>0 && nivel_punteros>0){
      bread(ptr,bloques_punteros[nivel_punteros-1]);
      indice=obtener_indice(nblog,nivel_punteros);
      ptr_nivel[nivel_punteros-1]=ptr;
      indices[nivel_punteros-1]=indice;
      ptr=bloques_punteros[nivel_punteros-1][indice];
      nivel_punteros--;
    }
    if(ptr>0){ //existe bloque de datos
      liberar_bloque(ptr);
      liberados++;
      if(nRangoBL==0) // puntero Directo
        inodo.punterosDirectos[nblog]=0;
      else{
        while(nivel_punteros < nRangoBL){
          indice=indices[nivel_punteros];
          bloques_punteros[nivel_punteros][indice]=0;
          ptr=ptr_nivel[nivel_punteros];
        	if(memcmp(bloques_punteros[nivel_punteros],bufferAux,BLOCKSIZE)==0){
            //No cuelgan bloques ocupados, hay que liberar el bloque de punteros
            liberar_bloque(ptr);
            liberados++;
            nivel_punteros++;
            if(nivel_punteros==nRangoBL) {
							inodo.punterosIndirectos[nRangoBL-1]=0;
						}
					}
          else{  //escribimos en el dispositivo el bloque de punteros modificado
						bwrite(ptr, bloques_punteros[nivel_punteros]);
            nivel_punteros=nRangoBL;// para salir del i
          }
      	}
    	}
  	}
	}
  return liberados;
}
/*
int liberar_bloques_inodo(unsigned int ninodo, unsigned int nblogico){

    struct inodo inodo;
	unsigned int nRangoBL, nivel_punteros, indice, ptr, nblog, ultimoBL;
    int bloques_punteros [3] [NPUNTEROS]; //array de bloques de punteros
    int ptr_nivel [3];  //punteros a bloques de punteros de cada nivel
    int indices[3];  //indices de cada nivel
    int liberados;  // nº de bloques liberados
  

  liberados=0;
  leer_inodo(ninodo, &inodo);
  if (inodo.tamEnBytesLog == 0)  return 0;  // el fichero vacío
  //obtenemos el último bloque lógico del inodo
  if (inodo.tamEnBytesLog % BLOCKSIZE == 0) {
	
  	ultimoBL = (inodo.tamEnBytesLog / BLOCKSIZE) - 1;
  } else ultimoBL = inodo.tamEnBytesLog / BLOCKSIZE;
  
  
  ptr= 0;

  for (nblog = nblogico; nblog <= ultimoBL; nblog++) {
    nRangoBL = obtener_nrangoBL(inodo, nblog, &ptr);
    if (nRangoBL < 0)  return -1; 
    nivel_punteros = nRangoBL;

    while (ptr > 0 && nivel_punteros > 0) { //cuelgan bloques de punteros
      bread(ptr, bloques_punteros[nivel_punteros-1]);
	  indice = obtener_indice(nblog, nivel_punteros);
      ptr_nivel[nivel_punteros-1] = ptr;
      indices[nivel_punteros-1] = indice;
      ptr = bloques_punteros[nivel_punteros-1][indice];
      nivel_punteros--;
    }

    if (ptr > 0) { //si existe bloque de datos
      liberar_bloque(ptr);
      liberados++;
		
      if (nRangoBL == 0 ){ //es un puntero Directo
		
        inodo.punterosDirectos[nblog]= 0;
      } else{
		
        while( nivel_punteros < nRangoBL) {
          indice = indices[nivel_punteros];
          bloques_punteros[nivel_punteros][indice] = 0;
          ptr = ptr_nivel [nivel_punteros];        
          if (bloques_punteros[nivel_punteros] == 0)  {

	  unsigned int bufAux[BLOCKSIZE];
	  memset(bufAux,0,BLOCKSIZE);
	  if(memcmp(bloques_punteros, bufAux, BLOCKSIZE)==0){
	  	liberar_bloque(ptr);
		liberados++;
	  }	

            //No cuelgan bloques ocupados, hay que liberar el bloque de punteros
            liberar_bloque(ptr);
            liberados++;
            nivel_punteros++;
            if (nivel_punteros == nRangoBL) { 
				inodo.punterosIndirectos[nRangoBL-1] = 0;
            } 
			
				
          } else{  //escribimos en el dispositivo el bloque de punteros modificado
            bwrite(ptr, bloques_punteros[nivel_punteros]); 
            nivel_punteros= nRangoBL; // para salir del bucle
          }
        }
      }
    }
  }
  return liberados;
}
*/









