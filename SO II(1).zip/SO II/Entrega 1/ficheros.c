#include "ficheros.h"

int mi_write_f(unsigned int ninodo, const void *buf_original, unsigned int offset, unsigned int nbytes) {
    // Nos aseguramos de que el inodo tenga permisos de escritura
    struct inodo inodo;
    leer_inodo (ninodo, &inodo);
    if ((inodo.permisos & 2) != 2) return -1;

    unsigned int primerBloqueLogico = offset/BLOCKSIZE;
    unsigned int ultimoBloqueLogico = (offset+nbytes-1)/BLOCKSIZE;
    
    if (primerBloqueLogico == ultimoBloqueLogico) { //Lo que queremos escribir solo ocupa un bloque
        int desp1 = offset % BLOCKSIZE;
        int bloqueFisico = traducir_bloque_inodo (ninodo, primerBloqueLogico, 1);
        if (bloqueFisico < 0) return -1;
        unsigned char buf_bloque [BLOCKSIZE];
        if (bread (bloqueFisico, buf_bloque) < 0) return -1;
            int desp2 = (offset+nbytes-1) % BLOCKSIZE;   
            memcpy (buf_bloque + desp1, buf_original, desp2-desp1+1);
        if (bwrite (bloqueFisico, buf_bloque) < 0) return -1;
    } else {    // Más de un bloque
        // 1) El primer bloque
        int bloqueFisico = traducir_bloque_inodo (ninodo, primerBloqueLogico, 1);
        unsigned char buf_bloque [BLOCKSIZE];
        if (bread (bloqueFisico,buf_bloque) < 0) return -1;
        int desp1 = offset % BLOCKSIZE;
        memcpy (buf_bloque + desp1, buf_original, BLOCKSIZE - desp1);
        if (bwrite (bloqueFisico, buf_bloque) < 0) return -1;
        
        // 2) Los bloques de enmedio, no hacemos ningún bread?
        int i;
        for (i = primerBloqueLogico + 1; i < ultimoBloqueLogico; i ++) {
            int bfisico = traducir_bloque_inodo (ninodo, i, 1);
            memcpy(buf_bloque, buf_original+(BLOCKSIZE-desp1)+(i-primerBloqueLogico-1)*BLOCKSIZE, BLOCKSIZE);
            if (bwrite (bfisico, buf_original + (BLOCKSIZE - desp1) + (i - primerBloqueLogico - 1) * BLOCKSIZE) < 0) return -1;
        }
        // 3) El último blque
        int bfisico = traducir_bloque_inodo (ninodo, ultimoBloqueLogico, 1);
        if (bread (bfisico, buf_bloque) < 0) return -1;
        int desp2 = (offset + nbytes - 1) % BLOCKSIZE;
        memcpy (buf_bloque, buf_original + (nbytes - desp2 - 1), desp2 + 1);
        if (bwrite (bfisico, (buf_original + (BLOCKSIZE - desp1) + (i - primerBloqueLogico - 1) * BLOCKSIZE) + 1) < 0) return -1; 
    }
    // Actualiza la metainformación del inodo
    leer_inodo(ninodo, &inodo);
    if(inodo.tamEnBytesLog<offset+nbytes && nbytes != 0) inodo.tamEnBytesLog = offset+nbytes;
    inodo.mtime = time(NULL);
    inodo.ctime = time(NULL);
    if(escribir_inodo(ninodo, inodo) < 0) return -1; //Escribimos el inodo modificado Error ESCRIBIR_INODO
    return nbytes;
}


int mi_read_f (unsigned int ninodo, void *buf_original, unsigned int offset, unsigned int nbytes) {
	struct inodo inodo;
	leer_inodo(ninodo, &inodo);
    inodo.atime = time(NULL);
    if(escribir_inodo(ninodo, inodo) < 0) return -1;

	if((inodo.permisos & 4) != 4) return -1; // No se tienen permisos para leer
	// La función no puede leer más allá del tamaño en bytes lógicos del inodo
	if (offset + nbytes >= inodo.tamEnBytesLog)
		nbytes = inodo.tamEnBytesLog - offset; //Leemos sólo los bytes que podemos desde el offset hasta el final de fichero
	if (offset > inodo.tamEnBytesLog) {
		return 0; // No podemos leer nada
	}
	if(nbytes == 0) {
	    return 0; //No leemos nada
    }
	unsigned char bufBloque[BLOCKSIZE]; //Leer el disco
	memset (bufBloque,0,BLOCKSIZE);//ponemos 0s en todo el buffer

	int bloqueI = offset/BLOCKSIZE, bloqueF = (offset+nbytes-1)/BLOCKSIZE;//bloque inicial y final
	unsigned int bfisico, bytes = 0;

	int	desp1 = offset%BLOCKSIZE; //Desplazamiento en el bloque
	int desp2 = (offset+nbytes-1) % BLOCKSIZE;

	if(bloqueI == bloqueF) { //Si son el mismo el bloque inicial y el final
		bfisico = traducir_bloque_inodo(ninodo, bloqueI, 0);
		bread(bfisico, bufBloque);
		memcpy (buf_original, bufBloque+desp1, desp2-desp1+1);
		bytes += desp2-desp1+1;	//Aumentamos el contador los bytes que hemos leido
	} else {
	//3 fases
	//  1) Primer bloque
	bfisico = traducir_bloque_inodo(ninodo,bloqueI,0);
	if(bfisico < 0)return bytes;
	else bread(bfisico, bufBloque);
	memcpy (buf_original, bufBloque+desp1, BLOCKSIZE-desp1);
	bytes += BLOCKSIZE-desp1;

	//  2) Intermedios
	int bucle;
	for(bucle = bloqueI+1; bucle < bloqueF; bucle++) {
		if((traducir_bloque_inodo(ninodo,bucle, 0)) < 0) return bytes;
		else bread(bfisico, bufBloque);
		memcpy(buf_original+(BLOCKSIZE-desp1)+(bucle-bloqueI-1)*BLOCKSIZE, bufBloque, BLOCKSIZE);
		bytes += BLOCKSIZE;
	}

	//  3) Ultimo bloque
	if((traducir_bloque_inodo(ninodo, bloqueF, 0)) < 0) return bytes;
	else bread(bfisico, bufBloque);
	memcpy (buf_original+(nbytes-desp2-1), bufBloque, desp2+1);
	bytes += desp2+1;
	}
	//Actualizaremos la metainformacion del inodo
	leer_inodo(ninodo, &inodo); //Por si el traducir_bloque_Inodo ha reservado inodos
	inodo.atime = time(NULL);
	if(escribir_inodo(ninodo, inodo) < 0) return -1; //Escribimos el inodo modificado
	

	return bytes;
}


//devolvemos la metainformacion del fichero/directorio indicado por parámetro.
int mi_stat_f(unsigned int ninodo, struct STAT *p_stat) {

	struct inodo inodo;
	leer_inodo(ninodo, &inodo);

	//Devolvemos la informacion
	p_stat->tipo = inodo.tipo;
	p_stat->permisos = inodo.permisos;
	p_stat->atime = inodo.atime;
	p_stat->mtime = inodo.mtime;
	p_stat->ctime = inodo.ctime;
	p_stat->nlinks = inodo.nlinks;
	p_stat->tamEnBytesLog = inodo.tamEnBytesLog;
	p_stat->numBloquesOcupados = inodo.numBloquesOcupados;

	return 0;
}

int mi_chmod_f(unsigned int ninodo, unsigned char permisos) {
    struct inodo inodo;
	leer_inodo(ninodo, &inodo);//leemos el inodo al que hay que modificar los permisos
	if(permisos < 0 || permisos > 7) return -1;
	inodo.permisos = permisos;//actualizamos permisos
	inodo.ctime = time(NULL);//actualizamos ctime
	if(escribir_inodo(ninodo, inodo) < 0) return -1; //Escribimos el inodo modificado
	return 0;
}

int mi_truncar_f(unsigned int ninodo, unsigned int nbytes) {
    struct inodo inodo;
	leer_inodo(ninodo, &inodo);
	int nblogico=0;
	
	//comprobamos que el inodo tenga permisos de escritura y que se pueda truncar
	if((inodo.permisos & 2) != 2) { fprintf(stderr, "\nNo tiene permiso de escritura\n"); exit(-1); }
	if(inodo.tamEnBytesLog<nbytes){ fprintf(stderr, "\nNo se puede truncar más allá del EOF\n"); return -1; }
	
	if(nbytes%BLOCKSIZE == 0) nblogico=nbytes/BLOCKSIZE;
	else {  nblogico=(nbytes/BLOCKSIZE) +1;}
	int liberados=liberar_bloques_inodo(ninodo,nblogico);
	if(liberados < 0) return -1; 
	leer_inodo(ninodo, &inodo);
	inodo.mtime = time(NULL);
	inodo.ctime = time(NULL);
	inodo.tamEnBytesLog = nbytes;
	inodo.numBloquesOcupados=inodo.numBloquesOcupados-liberados;
	if(escribir_inodo(ninodo, inodo) < 0) return -1; //Escribimos el inodo modificado
	fprintf(stderr, "\nlerasdafib: %d\n", liberados);
	return liberados;
}







