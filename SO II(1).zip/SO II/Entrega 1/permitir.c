#include "ficheros.h"

int main(int argc, char **argv){

	if (argc != 4) {
		perror("Numero de parametros incorrectos en permitir \n\n ./permitir - nombre del disco - n inodo- permisos");
		exit(-1);
	}
	
	int ninodo = atoi(argv[2]);
	int permisos = atoi(argv[3]);
	
	bmount(argv[1]);
		
	mi_chmod_f(ninodo, permisos);
  	
	bumount();
	
	
}
