#include "ficheros.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>

int main(int argc, char **argv){
	if (argc != 3) {
		perror("Numero de parametros incorrectos en leer\n\n./leer <nombre del disco> <inodo a leer> ('opcional' >>\"nombre de fichero a redireccionar\")");
		exit(-1);
	}

	if(bmount(argv[1])<0) printf("\nFallo al montar el disco\n");
	struct inodo inodo;
	leer_inodo(atoi(argv[2]), &inodo);
	if((inodo.permisos & 4) != 4) { fprintf(stderr, "\nNo tiene permiso de lectura\n"); exit(-1); } 
	char buffer[BLOCKSIZE];
	memset(buffer, 0, BLOCKSIZE);

	int offset = 0;
	int bytesLeidos=0;
	int bytesTotales=inodo.tamEnBytesLog;
	while(offset < bytesTotales) {
		memset(buffer,0, BLOCKSIZE);
		bytesLeidos= mi_read_f(atoi(argv[2]), buffer, offset, BLOCKSIZE);
		write(1, buffer, bytesLeidos);
		offset += bytesLeidos;		
	}

	fprintf(stderr,"\n\nBytes Leidos: %d" , offset);
	fprintf(stderr,"\nTamaño bytes logicos: %d \n" , bytesTotales);	
	
	bumount(argv[1]);
}
