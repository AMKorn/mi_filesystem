#include "ficheros.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/stat.h>
#include <inttypes.h>
#include <errno.h>

int main (int argc, char **argv){


	unsigned int offsets[5] = {0,5120,256000,30720000,71680000};
	
	if(argc != 4) printf ("Sintaxis Incorrecta: escribir <nombre_dispositivo> <\"$(cat fichero)\"> <diferentes_inodos(0/1)>"
 );	
 	else{
 		
		bmount(argv[1]);
		unsigned int ninodo;
		int i = 0;
		unsigned int nbytes;
		unsigned int bytes_escritos;
		struct STAT p_stat;
		
		struct inodo inodo;
		struct tm *ts;
    char atime[80];
    char mtime[80];
    char ctime[80];
		nbytes=strlen(argv[2]);	
		fprintf (stdout, "Longitud texto: %d", nbytes);
		char buffer[nbytes];
		memset(buffer, 0, nbytes);
		memcpy(buffer, argv[2], nbytes);

		if (atoi(argv[3]) == 0){ //un mismo inodo

			ninodo=reservar_inodo('f', 6);
			for (i; i <5; i++){
				printf("\n-------------------------------\n");
				bytes_escritos=mi_write_f(ninodo, buffer, offsets[i],nbytes);
				mi_stat_f(ninodo, &p_stat);
				fprintf(stderr,"\nNº Inodo reservado: %d", ninodo);
				fprintf(stderr,"\nOffset: %d", offsets[i]);
				fprintf(stderr,"\nBytes escritos: %d", nbytes);
				fprintf(stderr,"\nstat.tamBytesLogicos: %d", p_stat.tamEnBytesLog);
				fprintf(stderr,"\nstat.numBloquesOcupados: %d", p_stat.numBloquesOcupados);
				printf("\n-------------------------------\n");
				
				printf ("\nDatos inodo %d\n",ninodo); 
				leer_inodo(ninodo, &inodo);
				ts = localtime(&inodo.atime);
				strftime(atime, sizeof(atime), "%a %Y-%m-%d %H:%M:%S", ts);
				ts = localtime(&inodo.mtime);
				strftime(mtime, sizeof(mtime), "%a %Y-%m-%d %H:%M:%S", ts);
				ts = localtime(&inodo.ctime);
				strftime(ctime, sizeof(ctime), "%a %Y-%m-%d %H:%M:%S", ts);
				printf("TIPO: %c PERMISOS: %d\nNLINKS: %d TAMBYTESLOG: %d BLOQUES OCUPADOS: %d\nATIME: %s MTIME: %s CTIME: %s\n ",
				inodo.tipo, inodo.permisos, inodo.nlinks, inodo.tamEnBytesLog, inodo.numBloquesOcupados ,atime,mtime,ctime);
			}
		}else{
			for (i; i <5; i++){
				ninodo= reservar_inodo('f',6);
				bytes_escritos=mi_write_f(ninodo, buffer, offsets[i],nbytes);
				mi_stat_f(ninodo, &p_stat);
				fprintf(stderr,"\nNº Inodo reservado: %d", ninodo);
				fprintf(stderr,"\nOffset: %d", offsets[i]);
				fprintf(stderr,"\nBytes escritos: %d", nbytes);
				fprintf(stderr,"\nstat.tamBytesLogicos: %d", p_stat.tamEnBytesLog);
				fprintf(stderr,"\nstat.numBloquesOcupados: %d", p_stat.numBloquesOcupados);
				printf("\n==========================\n");

				printf ("\nDatos inodo %d\n",ninodo); 
				leer_inodo(ninodo, &inodo);
				ts = localtime(&inodo.atime);
				strftime(atime, sizeof(atime), "%a %Y-%m-%d %H:%M:%S", ts);
				ts = localtime(&inodo.mtime);
				strftime(mtime, sizeof(mtime), "%a %Y-%m-%d %H:%M:%S", ts);
				ts = localtime(&inodo.ctime);
				strftime(ctime, sizeof(ctime), "%a %Y-%m-%d %H:%M:%S", ts);
				printf("TIPO: %c PERMISOS: %d\nNLINKS: %d TAMBYTESLOG: %d BLOQUES OCUPADOS: %d\nATIME: %s MTIME: %s CTIME: %s\n ",
				inodo.tipo, inodo.permisos, inodo.nlinks, inodo.tamEnBytesLog, inodo.numBloquesOcupados ,atime,mtime,ctime);
			}
		}
	}
	bumount(argv[1]);
}
