Miembros del grupo:
    -Juan Amengual Jaume
    -Andrés Ramos Seguí
    -José Tur López
    
Observaciones:
    No hemos hecho ningún apartado extra.
