#include <string.h>
#include <stdio.h>
#include "ficheros_basico.h"

int main(int argc, char **argv){
	bmount(argv[1]);
	struct superbloque SB;
	bread(posSB, &SB);

	printf("primer bloqueMB: %u\n", SB.posPrimerBloqueMB); 
	printf("ultimoMB: %u\n", SB.posUltimoBloqueMB); 
	printf("primer AI: %u\n", SB.posPrimerBloqueAI); 
	printf("ultimo AI: %u\n", SB.posUltimoBloqueAI); 
	printf("primero datos: %u\n", SB.posPrimerBloqueDatos); 
	printf("ultimo datos: %u\n", SB.posUltimoBloqueDatos); 
	printf("inodoraiz: %u\n", SB.posInodoRaiz); 
	printf("primerinodolibre: %u\n", SB.posPrimerInodoLibre); 
	printf("bloqueslib: %u\n", SB.cantBloquesLibres); 
	printf("cantinodosLibres: %u\n", SB.cantInodosLibres);
	printf("totBloques: %u\n", SB.totBloques);
	printf("totInodos: %u\n", SB.totInodos);
	printf ("sizeof struct inodo is: %lu\n", sizeof(struct inodo));
	
	bumount();  
}


