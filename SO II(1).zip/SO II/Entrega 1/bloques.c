#include "bloques.h"

static int descriptor=0;

int bmount(const char *camino){
	descriptor=open(camino, O_RDWR|O_CREAT, 0666);
	if(descriptor>0){
		return descriptor;
	}
	return -1;	
}

int bumount(){
	if(close(descriptor)==0){
		return 0;
	}
	return -1;
}

int bwrite(unsigned int nbloque, const void *buf){
	if(lseek(descriptor, nbloque*BLOCKSIZE, SEEK_SET)==-1){
		return -1; //error moviendo el puntero
	}
	
	ssize_t bytes= write(descriptor, buf, BLOCKSIZE);
	if(bytes > 0){
		return bytes;
	}
	return -1;

}

int bread(unsigned int nbloque, void *buf){
	if(lseek(descriptor, nbloque*BLOCKSIZE, SEEK_SET)==-1){
		return -1; //error moviendo el puntero
	} 
	
	ssize_t bytes= read(descriptor, buf, BLOCKSIZE);
	if(bytes>0){
		return bytes;
	}
	return -1;

}
