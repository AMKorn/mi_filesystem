#include "directorios.h"


// En vez de usar el parámetro TIPO, devolvemos 1 si ha ido bien
int extraer_camino (const char *camino, char *inicial, char *final) {
    int i = 1; // i empieza en 1 por como hemos hecho en bucle, que mirará que el valor siguiente no sea '/'
    int f = 0;

	
	if (camino[0] != '/') return -1;   // ha de empezar si o si con '/'
	
    // inicial será lo que hay entre los dos '/' primeros o final
	while ((camino[i] != '/') && (camino[i] != '\0')){
		inicial[i-1] = camino[i];
		i++;
	}
	
	// si no hay nada más aparte de inicial
	if (i == strlen(camino)) {
		final = "\0";
		return 0; // 0 = Fichero
	}
	
	// volcamos el resto en final
	while (i < strlen(camino)) {
		final[f] = camino[i];
		i++; 
		f++;
	}
	return 1; //1 = Directorio
}


int buscar_entrada(const char *camino_parcial, unsigned int *p_inodo_dir, unsigned int *p_inodo, unsigned int *p_entrada, char reservar, unsigned char permisos) {
	//camino_parcial es “/”
	if(strcmp(camino_parcial,"/") == 0) {
		*p_inodo = 0; //la raiz siempre estara asociada al inodo 0
		*p_entrada = 0;
		return 0;
	}

	char inicial[60], final[strlen(camino_parcial)];
	memset(inicial, 0, 60);
	memset(final, 0, strlen(camino_parcial));

	struct inodo in;//, aux;
	int camino;
	if((camino = extraer_camino(camino_parcial,inicial,final)) < 0) return -10; //ERROR_EXTRAER_CAMINO

	//Buscamos la entrada cuyo nombre se encuentra en inicial
	int leer=leer_inodo(*p_inodo_dir,&in);
	struct entrada entr;
	memset(entr.nombre, 0, 60);
	int numEntr = in.tamEnBytesLog/sizeof(struct entrada);
	int nentrada = 0; //Num. entrada inicial
	if(numEntr > 0) {
		if((in.permisos & 4) != 4) return -11; //ERROR_PERMISO_LECTURA
		if(mi_read_f(*p_inodo_dir,&entr,nentrada*sizeof(struct entrada),sizeof(struct entrada)) < 0) return -3; //ERROR_LECTURA
		while(nentrada < numEntr && strcmp(inicial,entr.nombre)!= 0) {			
			nentrada++;
			if(mi_read_f(*p_inodo_dir,&entr,nentrada*sizeof(struct entrada),sizeof(struct entrada)) < 0) return -3; //ERROR_LECTURA
		}
	}
	if(nentrada == numEntr) { //La entrada no existe
		switch(reservar) {
		case 0: //modo consulta. Como no existe retornamos error
			return -12; //ERROR_NO_EXISTE_ENTRADA_CONSULTA
			break;
		case 1: //modo escritura. Creamos la entrada en el directorio referenciado por *p_inodo_dir
			strcpy(entr.nombre, inicial);
			int inR;
			//leer_inodo(0,&aux);
			if(camino == 1) { //DIRECTORIO
				if(strcmp(final,"/") == 0 && in.tipo != 'f') {//Revisamos que sea final y no estemos creando dentro de un fichero
					if((inR = reservar_inodo('d', permisos)) < 0) return -5; //ERROR_RESERVAR_INODO
				}
				else return -15; //ERROR_NO_EXISTE_DIRECTORIO_INTERMEDIO
			} else { //FICHERO
				if((inR = reservar_inodo('f', permisos)) < 0) return -5; //ERROR_RESERVAR_INODO
			}
			entr.ninodo = inR;
			if(mi_write_f(*p_inodo_dir,&entr,nentrada*sizeof(struct entrada), sizeof(struct entrada)) < 0) {
				//Si hay error, liberamos el inodo y devolvemos error
				if(liberar_inodo(entr.ninodo) < 0) return -17; //ERROR_LIBERAR_INODO
				return -1; //ERROR_ESCRITURA
			}
		}
	}
	if(strcmp(final,"/") == 0 || camino == 0) { //Hemos llegado al final del camino o es un fichero
		if((nentrada < numEntr) && (reservar == 1)) return -16; //ERROR_ENTRADA_YA_EXISTENTE
		*p_inodo = entr.ninodo;
		*p_entrada = nentrada;
	} else { //Si no es final extraemos de nuevo el camino
		*p_inodo_dir = entr.ninodo;
		switch(buscar_entrada(final, p_inodo_dir, p_inodo, p_entrada, reservar, permisos)) {
			case -1: return -1;
			case -10: return -10;
			case -3: return -3;
			case -5: return -5;
			case -11: return -11;
			case -12: return -12;
			case -13: return -13;
			case -14: return -14;
			case -15: return -15;
			case -16: return -16;
			case -17: return -17;
			case -18: return -18;
		}
	}
	return 0;
}

int mi_creat(const char *camino, unsigned char permisos) {
    mi_waitSem();
    unsigned int pid = 0, p_inodo = 0, pe = 0;  
	int bentrada = buscar_entrada(camino, &pid, &p_inodo, &pe, 1, permisos);
	if(bentrada < 0) {
		switch(bentrada){
			case -1: printf("Error al escribir la entrada"); break;
			case -3:  printf("\"%s\" Error lectura entrada\n", camino); break;
			case -5:  printf("\"%s\" Error en reservar inodo\n", camino); break;
			case -10: printf("Error en extraer camino\"%s\"\n", camino); break; 
			case -11: printf("No tiene permisos de lectura\n"); break;
			case -12: printf("No existe la entrada a consultar \"%s\"\n", camino); break;
			case -13: printf("No se puede crear entrada en un fichero\n"); break;
			case -14: printf("No tiene permisos de escritura\n"); break;
			case -15: printf("No existe directorio intermedio a \"%s\"\n", camino); break;
			case -16: printf("Ya existe la entrada \"%s\"\n", camino); break;
			case -17: printf("Error al liberar un inodo\n"); break;
			case -18: printf("Error en la lectura de \"%s\"\n", camino); break;    
			
		}
		puts("Error en MI_CREAT");
		mi_signalSem();
		return -1; 
	}
	mi_signalSem();
	return 0;
}

int mi_dir(const char *camino, char *buffer) {
    unsigned int pid = 0, p_inodo = 0, pe = 0;
	int bentrada = buscar_entrada(camino, &pid, &p_inodo, &pe, 0, 0);
	if(bentrada < 0) {
		switch(bentrada){
			case -1: printf("Error al escribir la entrada"); break;
			case -3:  printf("\"%s\" Error lectura entrada\n", camino); break;
			case -5:  printf("\"%s\" Error en reservar inodo\n", camino); break;
			case -10: printf("Error en extraer camino\"%s\"\n", camino); break; 
			case -11: printf("No tiene permisos de lectura\n"); break;
			case -12: printf("No existe la entrada a consultar \"%s\"\n", camino); break;
			case -13: printf("No se puede crear entrada en un fichero\n"); break;
			case -14: printf("No tiene permisos de escritura\n"); break;
			case -15: printf("No existe directorio intermedio a \"%s\"\n", camino); break;
			case -16: printf("Ya existe la entrada \"%s\"\n", camino); break;
			case -17: printf("Error al liberar un inodo\n"); break;
			case -18: printf("Error en la lectura de \"%s\"\n", camino); break;  
		}
		puts("Error en MI_DIR");
		return -1;
	}
	struct inodo inodo;
	leer_inodo(p_inodo,&inodo);
	struct entrada entrada;
	if(inodo.tipo == 'f') return -2; //ES UN FICHERO
	if(inodo.tipo != 'd' && inodo.permisos & 4) return -1;
	int numEntradas = inodo.tamEnBytesLog/sizeof(struct entrada);
	int nentrada = 0;
	printf("Total: %d\n", numEntradas);
	//Vamos obteniendo informacion de todas las entradas
	while(nentrada < numEntradas){
			if(mi_read_f(p_inodo,&entrada,nentrada*sizeof(struct entrada),sizeof(struct entrada)) < 0) return -2; //Leemos una entrada Error LECTURA
			leer_inodo(entrada.ninodo,&inodo);
			
			if(inodo.tipo == 'd') strcat(buffer,"d");
			else strcat(buffer,"f");
			strcat(buffer,"\t");
			//Para incorporar informacion acerca de los permisos:
			if(inodo.permisos & 4) strcat(buffer,"r");
			else strcat(buffer,"-");

			if(inodo.permisos & 2) strcat(buffer,"w");
			else strcat(buffer,"-");

			if(inodo.permisos & 1) strcat(buffer,"x");
			else strcat(buffer,"-");

			strcat(buffer, "\t");
			//Para incorporar informacion acerca del tiempo:
			struct tm *tm;
			char tmp[100];
			tm = localtime(&inodo.mtime);
			sprintf(tmp, "%d-%02d-%02d %02d:%02d:%02d\t", tm->tm_year+1900, tm->tm_mon+1, tm->tm_mday, tm->tm_hour, tm->tm_min, tm->tm_sec);
			strcat(buffer,tmp);

			char buffer1[10];
			snprintf(buffer1, 10, "%d", inodo.tamEnBytesLog);
			strcat(buffer,buffer1);

			strcat(buffer, "\t");
			strcat(buffer,entrada.nombre);
			strcat(buffer,"\n");
			nentrada++;
		}
	return numEntradas;
}


int mi_stat (const char *camino, struct STAT *p_stat) {
	unsigned int pid = 0, p_inodo = 0, pe = 0;
	int bentrada = buscar_entrada(camino, &pid, &p_inodo, &pe, 0, 0);

	if(bentrada < 0) {
		switch(bentrada){
			case -1: printf("Error al escribir la entrada"); break;
			case -3:  printf("\"%s\" Error lectura entrada\n", camino); break;
			case -5:  printf("\"%s\" Error en reservar inodo\n", camino); break;
			case -10: printf("Error en extraer camino\"%s\"\n", camino); break; 
			case -11: printf("No tiene permisos de lectura\n"); break;
			case -12: printf("No existe la entrada a consultar \"%s\"\n", camino); break;
			case -13: printf("No se puede crear entrada en un fichero\n"); break;
			case -14: printf("No tiene permisos de escritura\n"); break;
			case -15: printf("No existe directorio intermedio a \"%s\"\n", camino); break;
			case -16: printf("Ya existe la entrada \"%s\"\n", camino); break;
			case -17: printf("Error al liberar un inodo\n"); break;
			case -18: printf("Error en la lectura de \"%s\"\n", camino); break;  
		}
		printf("Error en MI_STAT");
		return -1;
	} else {
		if(mi_stat_f(p_inodo,p_stat) < 0) return -1; //Error STAT
	}
	return 0;
}

int mi_read (const char *camino, void *buf, unsigned int offset, unsigned int nbytes) {
	unsigned int pid = 0, p_inodo = 0, pe = 0, bytesLeidos; 
	int bentrada = buscar_entrada(camino, &pid, &p_inodo, &pe, 0, 0);
	if(bentrada < 0) {
		switch(bentrada){
			case -1: printf("Error al escribir la entrada"); break;
			case -3:  printf("\"%s\" Error lectura entrada\n", camino); break;
			case -5:  printf("\"%s\" Error en reservar inodo\n", camino); break;
			case -10: printf("Error en extraer camino\"%s\"\n", camino); break; 
			case -11: printf("No tiene permisos de lectura\n"); break;
			case -12: printf("No existe la entrada a consultar \"%s\"\n", camino); break;
			case -13: printf("No se puede crear entrada en un fichero\n"); break;
			case -14: printf("No tiene permisos de escritura\n"); break;
			case -15: printf("No existe directorio intermedio a \"%s\"\n", camino); break;
			case -16: printf("Ya existe la entrada \"%s\"\n", camino); break;
			case -17: printf("Error al liberar un inodo\n"); break;
			case -18: printf("Error en la lectura de \"%s\"\n", camino); break;  
		}
		printf("Error en MI_READ");
		return -1;
	} else {
		if((bytesLeidos = mi_read_f(p_inodo,buf,offset,nbytes)) < 0) return -1; //Error READ
	}
	return bytesLeidos;
}


int mi_write (const char *camino, const void *buf, unsigned int offset, unsigned int nbytes) {
	unsigned int pid = 0, p_inodo = 0, pe = 0, bytesEscritos;
	int bentrada = buscar_entrada(camino, &pid, &p_inodo, &pe, 0, 0); 

	struct inodo inodo;
	leer_inodo(p_inodo, &inodo);
	if((inodo.permisos & 2 )!=2){
		printf("\nError: No tiene permisos de escritura\n");
		return 0;
	}
	if(bentrada < 0) {
		switch(bentrada){
			case -1: printf("Error al escribir la entrada"); break;
			case -3:  printf("\"%s\" Error lectura entrada\n", camino); break;
			case -5:  printf("\"%s\" Error en reservar inodo\n", camino); break;
			case -10: printf("Error en extraer camino\"%s\"\n", camino); break; 
			case -11: printf("No tiene permisos de lectura\n"); break;
			case -12: printf("No existe la entrada a consultar \"%s\"\n", camino); break;
			case -13: printf("No se puede crear entrada en un fichero\n"); break;
			case -14: printf("No tiene permisos de escritura\n"); break;
			case -15: printf("No existe directorio intermedio a \"%s\"\n", camino); break;
			case -16: printf("Ya existe la entrada \"%s\"\n", camino); break;
			case -17: printf("Error al liberar un inodo\n"); break;
			case -18: printf("Error en la lectura de \"%s\"\n", camino); break;  
		}
		printf("Error en MI_WRITE");
		return -1;
	}

	struct inodo in;
	leer_inodo(p_inodo,&in);
	if(in.tipo != 'f'){
		puts("Se está intentando trabajar con un directorio.\n"); //Error LECTURA_DIRECTORIO
		return -3;
	}
	if((bytesEscritos = mi_write_f(p_inodo,buf,offset,nbytes)) < 0) return -1; //Error en el mi_write_f
	return bytesEscritos;
}


int mi_chmod(const char *camino, unsigned char permisos) {
    unsigned int pid = 0, p_inodo = 0, pe = 0;
	int bentrada = buscar_entrada(camino, &pid, &p_inodo, &pe, 0, 0);
	if(bentrada < 0) {
		switch(bentrada){
			case -1: printf("Error al escribir la entrada"); break;
			case -3:  printf("\"%s\" Error lectura entrada\n", camino); break;
			case -5:  printf("\"%s\" Error en reservar inodo\n", camino); break;
			case -10: printf("Error en extraer camino\"%s\"\n", camino); break; //-1 es lo mismo que -10
			case -11: printf("No tiene permisos de lectura\n"); break;
			case -12: printf("No existe la entrada a consultar \"%s\"\n", camino); break;
			case -13: printf("No se puede crear entrada en un fichero\n"); break;
			case -14: printf("No tiene permisos de escritura\n"); break;
			case -15: printf("No existe directorio intermedio a \"%s\"\n", camino); break;
			case -16: printf("Ya existe la entrada \"%s\"\n", camino); break;
			case -17: printf("Error al liberar un inodo\n"); break;
			case -18: printf("Error en la lectura de \"%s\"\n", camino); break; 
		}
		return -1;
	} else {
		if(mi_chmod_f(p_inodo,permisos) < 0) return -2; //Error CHMOD
	}
	return 0;
}


int mi_link(const char *camino1, const char *camino2) {
    mi_waitSem();
    unsigned int pid = 0, p_inodo = 0, pe = 0;
	int bentrada_origen = buscar_entrada(camino1, &pid, &p_inodo, &pe, 0, 0);
	if(bentrada_origen < 0) {
		switch(bentrada_origen){
			case -1: printf("Error al escribir la entrada"); break;
			case -3:  printf("\"%s\" Error lectura entrada\n", camino1); break;
			case -5:  printf("\"%s\" Error en reservar inodo\n", camino1); break;
			case -10: printf("Error en extraer camino\"%s\"\n", camino1); break; //-1 es lo mismo que -10
			case -11: printf("No tiene permisos de lectura\n"); break;
			case -12: printf("No existe la entrada a consultar \"%s\"\n", camino1); break;
			case -13: printf("No se puede crear entrada en un fichero\n"); break;
			case -14: printf("No tiene permisos de escritura\n"); break;
			case -15: printf("No existe directorio intermedio a \"%s\"\n", camino1); break;
			case -16: printf("Ya existe la entrada \"%s\"\n", camino1); break;
			case -17: printf("Error al liberar un inodo\n"); break;
			case -18: printf("Error en la lectura de \"%s\"\n", camino1); break; 
		}
		mi_signalSem();
		return -1;
	}
	mi_signalSem();;
	int inodo = p_inodo;
	struct inodo in;
	int leer=leer_inodo(inodo,&in);
	if(in.tipo != 'f') return -2; //Error porque camino1 ha de referirse a un fichero

	pid = 0, p_inodo = 0, pe = 0;
	mi_waitSem();
	int bentrada_destino = buscar_entrada(camino2, &pid, &p_inodo, &pe, 1, 6);
	if(bentrada_destino < 0) {
		switch(bentrada_destino){
			case -1: printf("Error al escribir la entrada"); break;
			case -3:  printf("\"%s\" Error lectura entrada\n", camino2); break;
			case -5:  printf("\"%s\" Error en reservar inodo\n", camino2); break;
			case -10: printf("Error en extraer camino\"%s\"\n", camino2); break; //-1 es lo mismo que -10
			case -11: printf("No tiene permisos de lectura\n"); break;
			case -12: printf("No existe la entrada a consultar \"%s\"\n", camino2); break;
			case -13: printf("No se puede crear entrada en un fichero\n"); break;
			case -14: printf("No tiene permisos de escritura\n"); break;
			case -15: printf("No existe directorio intermedio a \"%s\"\n", camino2); break;
			case -16: printf("Ya existe la entrada \"%s\"\n", camino2); break;
			case -17: printf("Error al liberar un inodo\n"); break;
			case -18: printf("Error en la lectura de \"%s\"\n", camino2); break; 
		}
		mi_signalSem();
		return -1;
	}
	mi_signalSem();
	struct entrada entr;
	//basura?
	if(mi_read_f(pid,&entr,pe*sizeof(struct entrada), sizeof(struct entrada)) < 0) return -3; //Error LECTURA
	mi_waitSem();
	liberar_inodo(p_inodo); //Liberamos el inodo que se ha asociado a la entrada creada
	mi_signalSem();
	entr.ninodo = inodo;
	if(mi_write_f(pid,&entr,pe*sizeof(struct entrada), sizeof(struct entrada)) < 0) return -4; //Error ESCRITURA
	mi_waitSem();
	in.nlinks++; //Actualizamos nlinks (tiene uno nuevo)
	in.ctime = time(NULL); //Actualizamos ctime
	escribir_inodo(inodo, in);
	mi_signalSem();
	return 0;
}


int mi_unlink(const char *camino) {
    mi_waitSem();
    unsigned int pid = 0, p_inodo = 0, pe = 0;
	int bentrada = buscar_entrada(camino, &pid, &p_inodo, &pe, 0, 0);
	if(bentrada < 0) {
		switch(bentrada){
			case -1: printf("Error al escribir la entrada"); break;
			case -3:  printf("\"%s\" Error lectura entrada\n", camino); break;
			case -5:  printf("\"%s\" Error en reservar inodo\n", camino); break;
			case -10: printf("Error en extraer camino\"%s\"\n", camino); break; //-1 es lo mismo que -10
			case -11: printf("No tiene permisos de lectura\n"); break;
			case -12: printf("No existe la entrada a consultar \"%s\"\n", camino); break;
			case -13: printf("No se puede crear entrada en un fichero\n"); break;
			case -14: printf("No tiene permisos de escritura\n"); break;
			case -15: printf("No existe directorio intermedio a \"%s\"\n", camino); break;
			case -16: printf("Ya existe la entrada \"%s\"\n", camino); break;
			case -17: printf("Error al liberar un inodo\n"); break;
			case -18: printf("Error en la lectura de \"%s\"\n", camino); break; 
		}
		mi_signalSem();
		return -1;
	} else {
	    mi_signalSem();
		struct inodo in;
		leer_inodo(pid,&in);
		int nentradas = in.tamEnBytesLog/sizeof(struct entrada);

		//Si no es la ultima entrada
		if(nentradas-1 != pe) {
			struct entrada entr;
			if(mi_read_f(pid, &entr, (nentradas-1) * sizeof(struct entrada), sizeof(struct entrada)) < 0) return -2; //Error LECTURA
			mi_write_f(pid,&entr, pe*sizeof(struct entrada), sizeof(struct entrada)); //Error ESCRITURA
		}
		mi_waitSem();
		if(mi_truncar_f(pid,(nentradas-1)*sizeof(struct entrada)) < 0) return -4; //Error TRUNCAR
        mi_signalSem();
        
		leer_inodo(p_inodo,&in);

		//Si no tiene mas links, borramos
		if(in.nlinks == 1) {
		    mi_waitSem();
			if(liberar_inodo(p_inodo) < 0) return -6; //Error LIBERAR_INODO
			mi_signalSem();
		} else { //Si no, actualizamos
			in.ctime = time(NULL);
			in.nlinks--; //Actualizamos nlinks (tiene uno menos)
			mi_waitSem();
			if(escribir_inodo(p_inodo, in) < 0)return -5; //Error ESCRIBIR_INODO
			mi_signalSem();
		}
	}
	return 0;
}




