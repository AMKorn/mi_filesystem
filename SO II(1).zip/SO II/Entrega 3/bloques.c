#include "bloques.h"


static sem_t *mutex;
static int descriptor=0;
static unsigned int inside_sc = 0;

int bmount(const char *camino) {
   if (descriptor > 0) {
       close(descriptor);
   }
   if ((descriptor = open(camino, O_RDWR | O_CREAT, 0666)) == -1) {
      fprintf(stderr, "Error: bloques.c  bmount()  open()\n");
   }
   if (!mutex) { //el semáforo es único y sólo se ha de inicializar una vez en nuestro sistema
       mutex = initSem();
          if (mutex == SEM_FAILED) {
           return -1;
       }
   }
   return descriptor;
}


int bumount() {
   descriptor = close(descriptor); 
   // hay que asignar el resultado de la operación a la variable ya que bmount() la utiliza
   if (descriptor == -1) {
       fprintf(stderr, "Error: bloques.c  bumount()  close(): %d: %s\n", errno, strerror(errno));
       return -1;
   }
   deleteSem(); // borramos semaforo
   return 0;
}


int bwrite(unsigned int nbloque, const void *buf){
	if(lseek(descriptor, nbloque*BLOCKSIZE, SEEK_SET)==-1){
		return -1; //error moviendo el puntero
	}
	
	ssize_t bytes= write(descriptor, buf, BLOCKSIZE);
	if(bytes > 0){
		return bytes;
	}
	return -1;

}

int bread(unsigned int nbloque, void *buf){
	if(lseek(descriptor, nbloque*BLOCKSIZE, SEEK_SET)==-1){
		return -1; //error moviendo el puntero
	} 
	
	ssize_t bytes= read(descriptor, buf, BLOCKSIZE);
	if(bytes>0){
		return bytes;
	}
	return -1;

}


void mi_waitSem(){
    if (!inside_sc) {
        waitSem(mutex);
    }
    inside_sc++;
}

void mi_signalSem() {
    inside_sc--;
    if (!inside_sc) {
        signalSem(mutex);
    }
}
