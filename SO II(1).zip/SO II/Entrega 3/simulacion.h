#include "directorios.h"

#define NOMBRE_FICHERO_PRUEBA "prueba.dat"
#define t_escritura   50000
#define t_proceso			200000     //0.2 Segundos
#define NUM_PROCESOS 100
#define NUM_REGISTROS 50
#define POS_MAX 500000

//Estructura para guardar en prueba.dat
struct REGISTRO {
	time_t fecha; //fecha de la escritura en formato epoc
	pid_t pid;  //PID del proceso que lo ha creado
	unsigned int nEscritura;  //Entero con el número de escritura (de 1 a 50)  (UNSIGNED?)
	unsigned int posicion;  //Entero con el número del registro dentro del fiche  (UNSIGNED?)
};

void reaper(); //Enterrador
