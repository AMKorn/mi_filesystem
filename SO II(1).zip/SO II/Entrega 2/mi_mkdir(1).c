#include "directorios.h"

int main (int argc, char **argv) {
	if (argc != 4) { //comprobamos sintaxis
		printf("Sintaxis correcta: mi_mkdir <disco> <permisos> <ruta>\n");
		return -1;
	}

	bmount(argv[1]);

	unsigned int permisos = atoi(argv[2]);

	if(permisos < 0 || permisos > 7) { //comprobamos que tenemos permisos
		printf("Permisos no válidos\n");
		bumount();
		return -1;
	}
	int ruta = strlen(argv[3])-1;

	if(argv[3][ruta] == '/') { //es un directorio
		if(mi_creat(argv[3], permisos) == 0){
			printf("El directorio %s se ha creado correctamente\n", argv[3]);
		} else printf("Error: fallo en mi_mkdir\n");
	} else { //es un fichero
		if(mi_creat(argv[3], permisos) == 0){
			printf("El archivo %s se ha creado correctamente\n", argv[3]);
		} else printf("Error: fallo en mi_mkdir\n");
	}
	bumount();
	return 0;
}
