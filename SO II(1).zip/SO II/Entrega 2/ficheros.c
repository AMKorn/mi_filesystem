#include "ficheros.h"

int mi_write_f (unsigned int inodo, const void *buf_original, unsigned int offset, unsigned int nbytes) {
	struct inodo mi_inodo;
  leer_inodo(inodo,&mi_inodo);
  //Comprobamos si el inodo tiene permisos de escritura y, en caso de que no, devolvemos -1.
	if((mi_inodo.permisos & 2) != 2) return -1;

	int bloqueI = offset/BLOCKSIZE;
  int bloqueF = (offset+nbytes-1)/BLOCKSIZE;
  int bfisico, bytes = 0;
	unsigned char bufBloque[BLOCKSIZE];
	int desp1 = offset%BLOCKSIZE; //Calculamos los desplazamientos
	int desp2 = (offset+nbytes-1)%BLOCKSIZE;

	if(bloqueI == bloqueF) {
		bfisico= traducir_bloque_inodo(inodo,bloqueI,1);
		if(bread(bfisico, bufBloque) == -1) return -1;
		memcpy (bufBloque+desp1, buf_original, desp2-desp1+1);
		if(bwrite(bfisico, bufBloque) == -1) return -1;
		bytes = nbytes;
	} else {
	    //Primer bloque
	    bfisico = traducir_bloque_inodo(inodo,bloqueI,1);
	    if(bread(bfisico, bufBloque) == -1) return -1;
	    memcpy (bufBloque+desp1, buf_original, BLOCKSIZE-desp1);
	    if(bwrite(bfisico, bufBloque) == -1) return -1;
	    bytes = BLOCKSIZE-desp1;

	    //Bloque intermedio
	    int bucle;
	    for(bucle = bloqueI+1; bucle < bloqueF; bucle++) {
		    bfisico= traducir_bloque_inodo(inodo,bucle,1);
				bytes += bwrite(bfisico, buf_original+(BLOCKSIZE-desp1)+(bucle-bloqueI-1)*BLOCKSIZE);
	    }

	    //Último bloque
	    bfisico= traducir_bloque_inodo(inodo,bloqueF,1);
	    if(bread(bfisico, bufBloque) == -1) return -1;
	    memcpy(bufBloque,buf_original+(nbytes-desp2-1),desp2+1);
	    if(bwrite(bfisico, bufBloque) == -1) return -1;
	    bytes += desp2+1;
	}
	leer_inodo(inodo,&mi_inodo);
	if(mi_inodo.tamEnBytesLog<offset+bytes) {
		mi_inodo.tamEnBytesLog = offset+bytes;
		mi_inodo.ctime = time(NULL);
	}
	mi_inodo.mtime = time(NULL);
	//Escribimos el inodo
	if(escribir_inodo(inodo, mi_inodo) == -1) {
		return -1;
	}
	return bytes;
}


int mi_read_f (unsigned int inodo, void *buf_original, unsigned int offset, unsigned int nbytes) {
	struct inodo mi_inodo;
	leer_inodo(inodo,&mi_inodo);

	//Comprobamos los permisos de lectura y, si el inodo no los tiene, devolvemos -1 (error).
	if((mi_inodo.permisos & 4) != 4) return -1;


	// El tamaño máximo de lectura es el tamaño en bytes lógicos del inodo
	// Lectura desde el offset hasta el final de fichero
	if (offset + nbytes >= mi_inodo.tamEnBytesLog) nbytes = mi_inodo.tamEnBytesLog - offset;
	//Si no se ha podido leer
	if (offset > mi_inodo.tamEnBytesLog || mi_inodo.tamEnBytesLog == 0){
		return 0;
	}
	if(nbytes == 0) return 0; //No leemos

	unsigned char bufBloque[BLOCKSIZE];
	memset(bufBloque,0,BLOCKSIZE);

	int bloqueI = offset/BLOCKSIZE;
	int bloqueF = (offset+nbytes-1)/BLOCKSIZE;
	int bfisico, bytes = 0;


	int	desp1 = offset%BLOCKSIZE; //Se calculan los desplazamientos en el bloque
	int desp2 = (offset+nbytes-1) % BLOCKSIZE;

	if(bloqueI == bloqueF) { //Si el bloque inicial y el final son iguales


		if((bfisico = traducir_bloque_inodo(inodo,bloqueI,0)) != -1)  {
			bread(bfisico, bufBloque);
			memcpy (buf_original, bufBloque+desp1, desp2-desp1+1);
		}
		bytes += desp2-desp1+1;
	} else {
		//3 fases
		//Primer bloque

		if((bfisico = traducir_bloque_inodo(inodo,bloqueI,0)) != -1) {
			bread(bfisico, bufBloque); //Si no hay error
			memcpy (buf_original, bufBloque+desp1, BLOCKSIZE-desp1);
		}
		bytes += BLOCKSIZE-desp1;

		//Intermedios
		int bucle;
		for(bucle = bloqueI+1; bucle < bloqueF; bucle++) {
			if((bfisico = traducir_bloque_inodo(inodo,bucle,0)) != -1 ){
				bread(bfisico, bufBloque);
				memcpy(buf_original+(BLOCKSIZE-desp1)+(bucle-bloqueI-1)*BLOCKSIZE, bufBloque, BLOCKSIZE);
			}
			bytes += BLOCKSIZE;
		}

		//Ultimo bloque
		if((bfisico = traducir_bloque_inodo(inodo,bloqueF,0)) != -1) {
			bread(bfisico, bufBloque);
			memcpy (buf_original+(nbytes-desp2-1), bufBloque, desp2+1);
		}
		bytes += desp2+1;
	}
	leer_inodo(inodo,&mi_inodo); //Leemos el inodo
	mi_inodo.atime = time(NULL);
	if(escribir_inodo(inodo, mi_inodo) == -1) {
		return -1; //Escribimos el inodo modificado en el superbloque
	}
	return bytes;
}


//devolvemos la metainformacion del fichero/directorio indicado por parámetro.
int mi_stat_f(unsigned int ninodo, struct STAT *p_stat) {

	struct inodo inodo;
	leer_inodo(ninodo, &inodo);
	printf("Nº inodo: %zu\n",ninodo); 
	//Devolvemos la informacion
	p_stat->tipo = inodo.tipo;
	p_stat->permisos = inodo.permisos;
	p_stat->atime = inodo.atime;
	p_stat->mtime = inodo.mtime;
	p_stat->ctime = inodo.ctime;
	p_stat->nlinks = inodo.nlinks;
	p_stat->tamEnBytesLog = inodo.tamEnBytesLog;
	p_stat->numBloquesOcupados = inodo.numBloquesOcupados;

	return 0;
}

int mi_chmod_f(unsigned int ninodo, unsigned char permisos) {
    struct inodo inodo;
	leer_inodo(ninodo, &inodo);//leemos el inodo al que hay que modificar los permisos
	if(permisos < 0 || permisos > 7) return -1;
	inodo.permisos = permisos;//actualizamos permisos
	inodo.ctime = time(NULL);//actualizamos ctime
	if(escribir_inodo(ninodo, inodo) < 0) return -1; //Escribimos el inodo modificado
	return 0;
}

int mi_truncar_f(unsigned int ninodo, unsigned int nbytes) {
    struct inodo inodo;
	leer_inodo(ninodo, &inodo);
	int nblogico=0;
	
	//comprobamos que el inodo tenga permisos de escritura y que se pueda truncar
	if((inodo.permisos & 2) != 2) { fprintf(stderr, "\nNo tiene permiso de escritura\n"); exit(-1); }
	if(inodo.tamEnBytesLog<nbytes){ fprintf(stderr, "\nNo se puede truncar más allá del EOF\n"); return -1; }
	
	if(nbytes%BLOCKSIZE == 0) nblogico=nbytes/BLOCKSIZE;
	else {  nblogico=(nbytes/BLOCKSIZE) +1;}
	int liberados=liberar_bloques_inodo(ninodo,nblogico);
	if(liberados < 0) return -1; 
	leer_inodo(ninodo, &inodo);
	inodo.mtime = time(NULL);
	inodo.ctime = time(NULL);
	inodo.tamEnBytesLog = nbytes;
	inodo.numBloquesOcupados=inodo.numBloquesOcupados-liberados;
	if(escribir_inodo(ninodo, inodo) < 0) return -1; //Escribimos el inodo modificado
	return liberados;
}







