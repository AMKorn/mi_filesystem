#include "directorios.h"

int main (int argc, char **argv) {
	if (argc != 3) {
		printf("Sintaxis correcta: mi_ls <disco> <ruta_directorio>\n");
		return -1;
	}
	//Montamos el disco
	if(bmount(argv[1]) < 0){
		printf("Error en la apertura del fichero: %s\n", argv[1]);
		return 0;
	}

	char buffer[64*200];
	memset(buffer,0,BLOCKSIZE);
	
	int dir=mi_dir (argv[2],(char *)buffer);
	if(dir >= 0) {
		if(buffer[0]!=0){
		printf("Directorio %s:\n", argv[2]);
		printf("%c[%d;%dmTipo\tPerm.\tmTime\t\t\tTamaño\tNombre%c[%dm\n",27,0,34,27,0); //color azul [0;34m
		puts("-------------------------------------------------------------------");
		printf("%s\n", buffer);}
	} else if (dir == -2) {
		puts("Error: no se admite el comando mi_ls para ficheros\n");
	} else {
		puts("Error: mi_ls ha fallado\n");
	}
	bumount();
	return 0;
}
