make
clear
source scripte2.sh
rm disco
make clean
