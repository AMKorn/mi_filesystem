/******************************************************************************
*                               DIRECTORIOS.C 
* PROYECTO: ENTREGA 2 - SISTEMAS OPERATIVOS II - GRADO ING. INFORMATICA - UIB
* DESCRIPCIÓN: FUNCIONES BÁSICA DE ENTRADA Y SALIDA DE BLOQUES.
* AUTORES: JUAN CARLOS BOO CRUGEIRAS
*          HÉCTOR MARIO MEDINA CABANELAS
* FECHA: 15 DE MAYO DE 2019.
******************************************************************************/

#include "ficheros.h"

#define     MAX_TAMANO  60

// ESTRUCTURA DIRECTORIO
struct entrada {
    char nombre[60];  //En el SF ext2 la longitud del nombre es 255
    unsigned int ninodo;
};



int extraer_camino(const char *camino, char *inicial, char *final, char *tipo);
int buscar_entrada(const char *camino_parcial, unsigned int *p_inodo_dir, unsigned int *p_inodo, unsigned int *p_entrada, char reservar, unsigned char permisos);
int mi_creat(const char *camino, unsigned char permisos);
int mi_touch(const char *camino, unsigned char permisos);
int mi_dir(const char *camino, char *buffer);
int mi_chmod(const char *camino, unsigned char permisos);