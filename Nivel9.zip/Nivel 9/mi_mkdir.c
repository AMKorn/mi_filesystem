/******************************************************************************
*                               DIRECTORIOS.C 
* PROYECTO: ENTREGA 1 - SISTEMAS OPERATIVOS II - GRADO ING. INFORMATICA - UIB
* DESCRIPCIÓN: FUNCIONES BÁSICA DE ENTRADA Y SALIDA DE BLOQUES.
* AUTORES: JUAN CARLOS BOO CRUGEIRAS
*          HÉCTOR MARIO MEDINA CABANELAS
* FECHA: 21 DE FEBRERO DE 2019.
******************************************************************************/

#include "directorios.h"

int main(int argc, char *argv[]){
    // Comprobamos que el numero de argumentos es el correcto
    if (argc != 4) {
      fprintf(stderr, "Error: Arg.1: Nombre disco. / Arg.2: Permisos. / Arg.3: Ruta.\n");
      exit(EXIT_FAILURE);
    } 
    // Comprobamos que el rango de permisos es el adecuado
    if(atoi(argv[2]) < 0 || atoi(argv[2]) > 7){
        fprintf(stderr, "Error: permisos debe estar en el rango 0-7");
        exit(EXIT_FAILURE);
    }
    // Montamos eldisco
    if (bmount(argv[1]) == -1) {
        fprintf(stderr, "Error: error de apertura de fichero.\n");
        exit(EXIT_FAILURE);
    }
    if(mi_creat(argv[3], atoi(argv[2])) == -1){
        fprintf(stderr, "Error en la funcion mi_creat()\n");
        exit(EXIT_FAILURE);
    }

    // Desmontamos el disco
    if (bumount() == -1) {
        fprintf(stderr, "Error: error al cerrar el fichero.\n");
        exit(EXIT_FAILURE);
    }
    return 0;
}