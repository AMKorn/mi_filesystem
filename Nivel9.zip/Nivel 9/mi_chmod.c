/******************************************************************************
*                               DIRECTORIOS.C 
* PROYECTO: ENTREGA 1 - SISTEMAS OPERATIVOS II - GRADO ING. INFORMATICA - UIB
* DESCRIPCIÓN: FUNCIONES BÁSICA DE ENTRADA Y SALIDA DE BLOQUES.
* AUTORES: JUAN CARLOS BOO CRUGEIRAS
*          HÉCTOR MARIO MEDINA CABANELAS
* FECHA: 21 DE FEBRERO DE 2019.
******************************************************************************/

#include "directorios.h"

int main(int argc, char *argv[]){
    // Comprobamos que el numero de argumentos es el correcto
    if (argc != 4) {
      fprintf(stderr, "Error: Arg.1: Nombre disco. / Arg.2: Permisos. / Arg.3: Ruta.\n");
      exit(EXIT_FAILURE);
    } 
    // Montamos el disco
    if (bmount(argv[1]) == -1) {
        fprintf(stderr, "Error: error de apertura de fichero.\n");
        exit(EXIT_FAILURE);
    }
    // Llamamos a la función mi_chmod()
    if(mi_chmod(argv[3], atoi(argv[2])) == -1){
        fprintf(stderr, "Error en la función mi_chmod()\n");
        exit(EXIT_FAILURE);
    }
    // Desmontamos el disco
    if (bumount() == -1) {
        fprintf(stderr, "Error: error al cerrar el fichero.\n");
        exit(EXIT_FAILURE);
    }
    return 0;
}

/*****************************************************************************/