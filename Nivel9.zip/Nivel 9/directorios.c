/******************************************************************************
*                               DIRECTORIOS.C 
* PROYECTO: ENTREGA 2 - SISTEMAS OPERATIVOS II - GRADO ING. INFORMATICA - UIB
* DESCRIPCIÓN: FUNCIONES BÁSICA DE ENTRADA Y SALIDA DE BLOQUES.
* AUTORES: JUAN CARLOS BOO CRUGEIRAS
*          HÉCTOR MARIO MEDINA CABANELAS
* FECHA: 15 DE MAYO DE 2019.
******************************************************************************/

#include "directorios.h"
#include <string.h>

int extraer_camino(const char *camino, char *inicial, char *final, char *tipo){
    const char ch = '/';
    int estado = 1;
    // Si el camino comianza por '/'
    if(camino[0] == ch){
        // Tratamos el inicial.
        int i;                      // Indice de camino.
        int j = 0;                  // Indice de inicial.
        for(i=1;camino[i] != ch || camino[i] == 0 ;i++){
            inicial[j] = camino[i]; // Asignamos camino a inicial por caracteres
            j++;                    // Aumentamos el indice de inicial.
        }
        inicial[j] = 0;             // Final de String en inicial.
        // Averiguamos si es directorio o fichero.
        if(camino[i] == ch){
            camino++;
            camino = strchr(camino, ch);  // Avanzamos al segundo '/' y actualizamos final
            strcpy(final, camino);
            strcpy(tipo, "d");          // Informamos que se trata de un directorio
        }
        else{
            strcpy(tipo, "f");          // Informamos de que se trata de un directorio.
        }
    }
    // Si el camino no comienza por '/'
    else{
        // Estado error
        estado = -1;
        // Imprimimos por la salida estandar de errores, el error.
        //fprintf(stderr, " Error: [extraer_camino()] --> camino inválido.\n");
    }
    // Devolvemos el estado de la ejecución de la función.
    return estado;
}

int buscar_entrada(const char *camino_parcial, unsigned int *p_inodo_dir, unsigned int *p_inodo, unsigned int *p_entrada, char reservar, unsigned char permisos){
    char inicial[MAX_TAMANO]; // LIMITE TAMAÑO TEMPORAL
    char final[MAX_TAMANO];   // LIMITE TAMAÑO TEMPORAL
    char tipo;
    struct entrada entradas[BLOCKSIZE / sizeof(struct entrada)];
    int numentradas = 0;
    memset(inicial, 0, MAX_TAMANO);
    memset(final, 0, MAX_TAMANO);
    printf("[buscar_entrada]--> Entra buscar entrada\n");    
    if(strcmp(camino_parcial, "/") == 0){
        p_inodo = 0;
        p_entrada = 0;
        return 0;
    }

    if(extraer_camino(camino_parcial, inicial, final, &tipo) == -1){
        fprintf(stderr, "[buscar_entrada]--> Error al extraer camino.\n");
        return -1;
    }
    printf("[buscar_entrada()→ inicial: %s, final: %s, reservar: %d]\n", inicial, final, reservar);
    
    struct inodo inodo_dir;
    if(leer_inodo(*p_inodo_dir, &inodo_dir) == -1){
        fprintf(stderr, "[buscar_entrada]--> Error de lectura del inodo\n");
        return -1;
    }

    // COMPROBAMOS LOS PERMISOS DEL INODO
    if((inodo_dir.permisos & 4) != 4){
        fprintf(stderr, "[buscar_entrada]--> Error en los permisos del inodo\n");
        return -1;
    }

    memset(entradas, 0, sizeof(entradas));
    numentradas = inodo_dir.tamEnBytesLog/sizeof(struct entrada);

    int nentrada = 0;
    int offset = 0;
    int index = 0;

    printf("[buscar_entrada]--> Antes del bucle 1\n");
    if(numentradas > 0){
        mi_read_f(*p_inodo_dir, entradas, offset, BLOCKSIZE);
        while((nentrada < numentradas) && ((strcmp(inicial, entradas[index].nombre) != 0))){
            nentrada++;
            index++;
            offset += sizeof(struct entrada);
            if(index == BLOCKSIZE / sizeof(struct entrada)){
                index = 0;
                mi_read_f(*p_inodo_dir, entradas, offset, BLOCKSIZE);
            }
        }
    }
    printf("[buscar_entrada]--> Entre bucles 1 y 2\n");

    if(nentrada == numentradas){
    switch(reservar){
        case 0:
            fprintf(stderr, "[buscar_entrada]--> Error: No existe entrada consulta.\n");
            return -1;
        case 1:
            if(inodo_dir.tipo == 'f'){
                fprintf(stderr, "[buscar_entrada]--> Error: No se puede crear una entrada en un fichero.\n");
                return -1;
            }
            if((inodo_dir.permisos & 2) != 2){
                fprintf(stderr, "[buscar_entrada]--> Error: Fallo en permiso escritura.\n");
                return -1;
            } else {
                strcpy(entradas[index].nombre, inicial);
                if(tipo == 'd'){
                    if(strcmp(final, "/") == 0){
                        int ninodo = reservar_inodo(tipo, permisos);
                        entradas[index].ninodo = ninodo;

                    } else {
                        fprintf(stderr, "[buscar_entrada]--> Error: No existe directorio intermedio.\n");
                        return -1;
                    }
                } else {
                    int ninodo = reservar_inodo('f', permisos);
                    entradas[index].ninodo = ninodo;
                }
                if(mi_write_f(*p_inodo_dir, &entradas[index], offset, sizeof(struct entrada)) == -1){
                    if(entradas[index].ninodo != -1){
                        liberar_inodo(entradas[index].ninodo);
                    }
                    fprintf(stderr, "[buscar_entrada]--> Error: Exit failure.\n");
                    return -1;
                }
            }
        }
    } 

    printf("[buscar_entrada]--> Sale de bucle 2\n");
    if(strcmp(final, "/") == 0){
        if((nentrada < numentradas) && (reservar == 1)){
            fprintf(stderr, "[buscar_entrada]--> Error: Entrada ya existe.\n");
            return -5;
        }
        printf("[buscar_entrada()→ entrada.nombre: %s, entrada.ninodo: %d]\n",entradas[index].nombre, entradas[index].ninodo);
        printf("[buscar_entrada()→ reservado inodo %d tipo %c con permisos %d]\n", entradas[index].ninodo, inodo_dir.tipo,permisos);
        *p_inodo = entradas[index].ninodo;
        *p_entrada = nentrada;
    } else {
        *p_inodo_dir = entradas[index].ninodo;
        return buscar_entrada(final, p_inodo_dir, p_inodo, p_entrada, reservar, permisos);
    }
    return 0;
}



// NIVEL 9

int mi_creat(const char *camino, unsigned char permisos){
    unsigned int p_inodo_dir, p_inodo, p_entrada;
    // Inicializamos reservar a 1 y el inodo padre a 0 (inodo raiz)
    char reservar = 1;
    p_inodo_dir = 0;
    // Si la direccion pertenece a un fichero debe usarse la función mi_touch
/**    if(camino[strlen(camino) - 1] != '/'){
        fprintf(stderr, "Error: para crear un fichero se debe usar la función mi_touch\n");
        exit(EXIT_FAILURE);
    }**/
    // Buscar entrada creara un nuevo directorio si en parámetro 'reservar' recibe un 1
    if(buscar_entrada(camino, &p_inodo_dir, &p_inodo, &p_entrada, reservar, permisos) == -1){
        fprintf(stderr, "Error en buscar entrada\n");
        exit(EXIT_FAILURE);
    }
    return 0;
}

int mi_touch(const char *camino, unsigned char permisos){
    unsigned int p_inodo_dir, p_inodo, p_entrada;
    // Inicializamos reservar a 1 y el inodo padre a 0 (inodo raiz)
    char reservar = 1;
    p_inodo_dir = 0;
    // Comprobamos que tenga un rango de permisos aceptable
    if(permisos < 0 || permisos > 7){
        fprintf(stderr, "Rango de permisos\n");
        exit(EXIT_FAILURE);
    }
    // Si la direccion pertenece a un directorio debe usarse la función mi_creat
    if(camino[strlen(camino) - 1] == '/'){
        fprintf(stderr, "Error: para crear un directorio se debe usar la función mi_creat\n");
        exit(EXIT_FAILURE);
    }

    // Buscar entrada creará un nuevo directorio si en parámetro 'reservar' recibe un 1
    if(buscar_entrada(camino, &p_inodo_dir, &p_inodo, &p_entrada, reservar, permisos) == -1){
        fprintf(stderr, "Error en buscar entrada");
        exit(EXIT_FAILURE);
    }
    return 0;
}


int mi_dir(const char *camino, char *buffer){
    int entr, nEntradas;
    struct inodo inodoAux;
    struct entrada entrada;
	unsigned int p_inodo_dir = 0, p_inodo = 0, p_entrada = 0;
    struct tm *tm; //ver info: struct tm
    char tmp[100];
    entr = buscar_entrada(camino, &p_inodo_dir, &p_inodo, &p_entrada, 0, 7);
    leer_inodo(p_inodo, &inodoAux);
    nEntradas = inodoAux.tamEnBytesLog/sizeof(struct entrada); // calculamos el número de entradas
    memset(buffer, 0, strlen(buffer)*sizeof(char));
    strcat(buffer,"Tipo\t Permisos\t mTime\t\t\t\t Tamaño\t\t Nombre");
    char str[10];
    memset(str, 0, 10*sizeof(char));
    for (int i = 0; i < nEntradas; i++) {
    if (mi_read_f(p_inodo, &entrada, (i * sizeof(struct entrada)), sizeof(struct entrada)) == -1) return -1;
    if (leer_inodo(entrada.ninodo, &inodoAux) == -1) return -1;
        strcat(buffer, "\n");
        str[0] = inodoAux.tipo;
        str[1] = '\0';
        strcat(buffer, str);
        strcat(buffer, "\t");

        if(inodoAux.permisos & 4){
            strcat(buffer, "r");
        }
        else{
            strcat(buffer, "-");
        }
        if(inodoAux.permisos & 2){
            strcat(buffer, "w");
        }
        else{
            strcat(buffer, "-");
        }
        if(inodoAux.permisos & 1){
            strcat(buffer, "x");
        }
        else{
            strcat(buffer, "-");
        }
        strcat(buffer, "\t\t");
        tm = localtime(&inodoAux.mtime);
        sprintf(tmp,"%d-%02d-%02d %02d:%02d:%02d\t",tm->tm_year+1900,
        tm->tm_mon+1,tm->tm_mday,tm->tm_hour,tm->tm_min,tm->tm_sec);
        strcat(buffer,tmp);
        strcat(buffer, "\t");
        sprintf(str, "%d", inodoAux.tamEnBytesLog);
        strcat(buffer, str);
        strcat(buffer,"\t\t");
    	strcat(buffer,entrada.nombre);
    }
    strcat(buffer, "\n");
    return entr;
}

int mi_chmod(const char *camino, unsigned char permisos){
    unsigned int p_inodo_dir, p_inodo, p_entrada;
    // Inicializamos reservar a 1 y el inodo padre a 0 (inodo raiz)
    char reservar = 0;
    p_inodo_dir = 0;
    
    if(buscar_entrada(camino, &p_inodo_dir, &p_inodo, &p_entrada, reservar, permisos) == -1){
        fprintf(stderr, "Error en buscar_entrada()\n");
        exit(EXIT_FAILURE);
    }
    
    if(mi_chmod_f(p_inodo, permisos) == -1){
        fprintf(stderr, "Error en la función mi_chmod_f()\n");
        exit(EXIT_FAILURE);
    }
    return 0;
} 

int mi_stat(const char *camino, struct STAT *p_stat){
    unsigned int p_inodo_dir, p_inodo, p_entrada;
    unsigned char permisos = 7;
    // Inicializamos reservar a 1 y el inodo padre a 0 (inodo raiz)
    char reservar = 1;
    p_inodo_dir = 0;
    // Llamamos a buscar_entrada()
    if(buscar_entrada(camino, &p_inodo_dir, &p_inodo, &p_entrada, reservar, permisos) == -1){
        fprintf(stderr, "Error en buscar_entrada()");
        exit(EXIT_FAILURE);
    }
    // Llamamos a mi_stat_f()
    if(mi_stat_f(p_inodo, p_stat) == -1){
        fprintf(stderr, "Error en la función mi_stat_f()\n");
        exit(EXIT_FAILURE);
    }
    
    return 0;
}


// NIVEL 10